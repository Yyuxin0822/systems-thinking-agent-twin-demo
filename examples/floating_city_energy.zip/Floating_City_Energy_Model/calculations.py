#!/usr/bin/env python3
"""Reproducible screening model. Standard library only; no weather simulation.

Run from any directory: python3 calculations.py
Regenerates instance data, ledger, and validation.json from scenario.json.
The bundled DTDL definitions in model.json are preserved unchanged.
"""
import json
import math
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
P = json.loads((ROOT / 'scenario.json').read_text())
MODELS = json.loads((ROOT / 'model.json').read_text())
PREFIX = 'fc63-'
SYSTEM = 'fc63-energy-12000'
PERIOD = {'id': 'design_year_1', 'duration_days': P['days_per_year'],
          'start': 'design_year_start', 'end': 'design_year_end',
          'interpretation': 'Synthetic 365-day operating year; no calendar or location implied.'}

def save(name, obj):
    (ROOT / name).write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')

def q(value, unit):
    return {'value': round(float(value), 9), 'unit': unit}

# All rates/totals are converted to MWh over the same 365-day accounting period.
gfa = P['population'] * P['floor_area_m2_per_person']
appliances = gfa * P['non_hvac_electricity_kwh_m2_year'] / 1000
space_heat = gfa * P['space_heat_kwh_thermal_m2_year'] / 1000
cooling = gfa * P['cooling_kwh_thermal_m2_year'] / 1000
hot_water = P['population'] * P['hot_water_kwh_thermal_person_day'] * P['days_per_year'] / 1000
tank_loss = hot_water * P['hot_water_tank_loss_fraction_of_delivery']
tank_charge = hot_water + tank_loss
heating_e = space_heat / P['heating_seasonal_cop']
cooling_e = cooling / P['cooling_seasonal_cop']
hot_water_e = tank_charge / P['hot_water_seasonal_cop']
hp_e = heating_e + cooling_e + hot_water_e
municipal = P['municipal_electricity_mwh_year']
aux = P['plant_auxiliary_electricity_mwh_year']
demand = appliances + hp_e + municipal + aux
pv_site = P['onsite_pv_mwp_dc'] * P['pv_yield_kwh_kwp_year']
pv_shore = P['offsite_pv_mwp_dc'] * P['pv_yield_kwh_kwp_year']
generation = pv_site + pv_shore
batt_in = P['battery_charge_mwh_day'] * P['days_per_year']
batt_out = batt_in * P['battery_round_trip_efficiency']
batt_loss = batt_in - batt_out
network_loss = generation * P['network_loss_fraction_of_pv_generation']
net_export = generation - demand - batt_loss - network_loss
pv_site_area = P['onsite_pv_mwp_dc'] * 1000 / P['pv_module_kwp_m2']
pv_shore_area = P['offsite_pv_mwp_dc'] * 1000 / P['pv_module_kwp_m2']
solar_site = pv_site_area * P['pv_plane_irradiance_kwh_m2_year'] / 1000
solar_shore = pv_shore_area * P['pv_plane_irradiance_kwh_m2_year'] / 1000
ambient_heat = space_heat + tank_charge - heating_e - hot_water_e
cooling_rejection = cooling + cooling_e
building_other_release = appliances + space_heat + hot_water - cooling
tank_water = P['thermal_tank_volume_m3'] * P['water_density_kg_m3']
tank_energy = tank_water * P['water_specific_heat_kj_kg_k'] * (P['thermal_tank_initial_c'] - P['thermal_tank_reference_c']) / 3600000
tank_usable = tank_water * P['water_specific_heat_kj_kg_k'] * (P['thermal_tank_maximum_c'] - P['thermal_tank_minimum_c']) / 3600000

twins, relationships, assets, stock_records, flow_records, boundary_records = [], [], [], [], [], []

def asset(key, name, role, description, boundary, stock=None, capacity=None, balance_scope='modeled'):
    tid = PREFIX + key
    stock = stock or {}
    twins.append({'$dtId': tid, '$metadata': {'$model': f'dtmi:environmental:{role}Twin;3'},
                  'name': name, 'system': SYSTEM, 'stock': stock})
    assets.append({'twin_id': tid, 'description': description, 'role': role.lower(),
                   'boundary_status': boundary, 'balance_scope': balance_scope,
                   'capacities_and_design_parameters': capacity or {},
                   'status': 'proposed' if key != 'grid' else 'external_existing_asset_to_be_identified',
                   'unknown_material_stocks': 'Bills of materials are unresolved; not represented as zero.'})
    for sk, sv in stock.items():
        stock_records.append({'twin_id': tid, 'stock_key': sk, **sv,
                              'reference_time': 'design_year_start', 'end_value': sv['value'],
                              'end_reference_time': 'design_year_end', 'delta': 0.0,
                              'evidence': 'assumed initial condition; equal year-end state is an annual balance constraint'})
    return tid

asset('city', 'City', 'Process', 'Assembly of the floating platforms, buildings and onsite infrastructure.',
      'city', capacity={'site_area': q(P['city_area_m2'], 'm2'), 'population': q(P['population'], 'person')},
      balance_scope='containment_only_do_not_double_count_children')
asset('pv', 'Roof PV', 'Input', 'PV modules and inverters on roofs and circulation canopies.', 'city',
      capacity={'dc_capacity': q(P['onsite_pv_mwp_dc'], 'MWp'), 'module_area': q(pv_site_area, 'm2'),
                'roof_module_area': q(18000, 'm2'), 'canopy_module_area': q(3000, 'm2'),
                'ac_yield': q(P['pv_yield_kwh_kwp_year'], 'kWh/kWp/year')})
asset('shore-pv', 'Shore PV', 'Input', 'Dedicated project-owned onshore PV plant with its generation attributes retained.',
      'outside_city_inside_project', capacity={'dc_capacity': q(P['offsite_pv_mwp_dc'], 'MWp'),
      'module_area': q(pv_shore_area, 'm2'), 'land_reservation': q(P['offsite_pv_land_m2'], 'm2'),
      'ac_yield': q(P['pv_yield_kwh_kwp_year'], 'kWh/kWp/year')})
asset('network', 'Power Link', 'Process', 'Identifiable assembly of shore switchgear, submarine cable, city switchgear and distribution conductors.',
      'straddles_city_inside_project', capacity={'city_link': q(P['city_link_mva'], 'MVA'),
      'shore_hub': q(P['shore_hub_mva'], 'MVA'), 'assumed_city_peak': q(P['assumed_peak_electricity_mw'], 'MW'),
      'loss_allowance_basis': '2% of annual PV AC production; not a cable/load-flow calculation'})
asset('battery', 'Battery', 'Process', 'Stationary battery racks, enclosures and bidirectional converters.', 'city',
      stock={'storedElectricity': q(P['battery_initial_stored_mwh'], 'MWh')},
      capacity={'nameplate_energy': q(P['battery_nameplate_mwh'], 'MWh'), 'converter_power': q(P['battery_power_mw'], 'MW'),
      'minimum_stored_energy': q(P['battery_nameplate_mwh'] * P['battery_minimum_soc'], 'MWh'),
      'maximum_stored_energy': q(P['battery_nameplate_mwh'] * P['battery_maximum_soc'], 'MWh'),
      'round_trip_efficiency': q(P['battery_round_trip_efficiency'], 'fraction'),
      'reserved_compound_area': q(1000, 'm2')})
asset('hp', 'Heat Pumps', 'Process', 'Distributed reversible air-source heat-pump/chiller units and dedicated hot-water heat-pump units.', 'city',
      capacity={'space_heating': q(gfa * P['peak_space_heat_w_m2'] / 1e6, 'MW_thermal'),
      'space_cooling': q(gfa * P['peak_cooling_w_m2'] / 1e6, 'MW_thermal'),
      'hot_water_heating': q(P['hot_water_plant_mw_thermal'], 'MW_thermal'),
      'seasonal_heating_cop': q(P['heating_seasonal_cop'], 'MWh_thermal/MWh_electric'),
      'seasonal_cooling_cop': q(P['cooling_seasonal_cop'], 'MWh_thermal/MWh_electric'),
      'seasonal_hot_water_cop': q(P['hot_water_seasonal_cop'], 'MWh_thermal/MWh_electric'),
      'coincidence_and_extreme_temperature_capacity': 'unresolved'})
asset('tanks', 'Hot Tanks', 'Process', 'Distributed sealed buffer-water tanks and heat exchangers serving domestic hot water.', 'city',
      stock={'containedWater': q(tank_water, 'kg'), 'storedHeat': q(tank_energy, 'MWh')},
      capacity={'water_volume': q(P['thermal_tank_volume_m3'], 'm3'),
      'temperature_at_snapshot': q(P['thermal_tank_initial_c'], 'degC'),
      'energy_reference_temperature': q(P['thermal_tank_reference_c'], 'degC'),
      'minimum_operating_temperature': q(P['thermal_tank_minimum_c'], 'degC'),
      'maximum_operating_temperature': q(P['thermal_tank_maximum_c'], 'degC'),
      'usable_heat_over_operating_band': q(tank_usable, 'MWh')})
asset('buildings', 'Buildings', 'Output', 'Occupied building assemblies, equipment and domestic hot-water heat exchangers.', 'city',
      capacity={'gross_floor_area': q(gfa, 'm2'), 'building_footprint': q(P['building_footprint_m2'], 'm2'),
      'mean_storeys': q(gfa / P['building_footprint_m2'], 'storey'),
      'annual_non_hvac_eui': q(P['non_hvac_electricity_kwh_m2_year'], 'kWh/m2/year')})
asset('utilities', 'Utilities', 'Output', 'Water-treatment equipment, wastewater equipment and municipal pumps serving the city.', 'city',
      capacity={'annual_electricity_budget': q(municipal, 'MWh/year'),
      'treatment_processes_and_peak_capacities': 'unresolved; municipal allowance does not establish water-system feasibility'})
asset('aux', 'Plant Aux', 'Process', 'Heat-distribution pumps, controls, metering equipment and energy-management controller hardware.', 'city',
      capacity={'annual_electricity_budget': q(aux, 'MWh/year')})
asset('courts', 'Shade Courts', 'Process', 'Planted courtyard assemblies within the floating platform footprint.', 'city',
      capacity={'planting_area': q(P['planted_courts_m2'], 'm2')}, balance_scope='unquantified_supporting_asset_no_energy_credit')
asset('grid', 'Grid Station', 'Output', 'External utility substation receiving net project exports and supplying temporal deficits.',
      'outside_project', balance_scope='net_exchange_port_only')

def transfer(key, source, target, label, quantity, value, carrier, method='calculated', aggregation='annual_total'):
    rid = PREFIX + key
    relationships.append({'$relationshipId': rid, '$sourceId': PREFIX + source, '$targetId': PREFIX + target,
                          '$relationshipName': 'flowsTo', 'name': label, 'system': SYSTEM,
                          'flow': {quantity: q(value, 'MWh')}})
    flow_records.append({'source_twin': PREFIX + source, 'relationship_id': rid,
                         'target_twin': PREFIX + target, 'flow_key': quantity, **q(value, 'MWh'),
                         'carrier': carrier, 'period_id': PERIOD['id'], 'time_basis': 'total_per_365_day_year',
                         'aggregation': aggregation, 'evidence': method})

transfer('roof-power', 'pv', 'network', 'PV electricity', 'electricity', pv_site, 'electricity', '4.2 MWp * assumed AC yield')
transfer('shore-power', 'shore-pv', 'network', 'PV electricity', 'electricity', pv_shore, 'electricity', '18 MWp * assumed AC yield')
transfer('charge', 'network', 'battery', 'Battery charge', 'electricity', batt_in, 'electricity', 'assumed 6 MWh/day charge throughput')
transfer('discharge', 'battery', 'network', 'Battery discharge', 'electricity', batt_out, 'electricity', 'charge * 0.85 round-trip efficiency')
transfer('building-power', 'network', 'buildings', 'Building electricity', 'electricity', appliances, 'electricity')
transfer('hp-power', 'network', 'hp', 'Heat-pump electricity', 'electricity', hp_e, 'electricity')
transfer('utility-power', 'network', 'utilities', 'Utility electricity', 'electricity', municipal, 'electricity', 'budget assumption')
transfer('aux-power', 'network', 'aux', 'Auxiliary electricity', 'electricity', aux, 'electricity', 'budget assumption')
transfer('space-heat', 'hp', 'buildings', 'Space heat', 'heat', space_heat, 'thermal_energy')
transfer('cooling', 'buildings', 'hp', 'Heat removed', 'heat', cooling, 'thermal_energy', 'cooling is heat moving FROM buildings')
transfer('tank-charge', 'hp', 'tanks', 'Tank heat charge', 'heat', tank_charge, 'thermal_energy')
transfer('hot-water', 'tanks', 'buildings', 'Hot-water heat', 'heat', hot_water, 'thermal_energy')
transfer('net-grid', 'network', 'grid', 'Net grid exchange', 'netElectricity', net_export, 'electricity',
         'exports minus imports; gross imports and exports unresolved without hourly dispatch', 'annual_net_export')

for child in ['pv', 'battery', 'hp', 'tanks', 'buildings', 'utilities', 'aux', 'courts']:
    relationships.append({'$relationshipId': PREFIX + 'contains-' + child, '$sourceId': PREFIX + 'city',
                          '$targetId': PREFIX + child, '$relationshipName': 'contains'})

def boundary(key, asset_key, direction, value, carrier, label, evidence='calculated energy-balance residual'):
    boundary_records.append({'id': key, 'asset_twin': PREFIX + asset_key, 'direction': direction,
        'external_domain': label, **q(value, 'MWh'), 'carrier': carrier,
        'period_id': PERIOD['id'], 'time_basis': 'total_per_365_day_year', 'evidence': evidence,
        'schema_route': 'ledger boundary_transfers extension; no artificial resource or loss twin'})

boundary('roof-irradiance', 'pv', 'in', solar_site, 'solar_radiation', 'incident sunlight', 'assumed 1600 kWh/m2/year * module area')
boundary('roof-non-electric', 'pv', 'out', solar_site - pv_site, 'thermal_and_radiant_energy', 'reflected sunlight and dissipated heat')
boundary('shore-irradiance', 'shore-pv', 'in', solar_shore, 'solar_radiation', 'incident sunlight', 'assumed 1600 kWh/m2/year * module area')
boundary('shore-non-electric', 'shore-pv', 'out', solar_shore - pv_shore, 'thermal_and_radiant_energy', 'reflected sunlight and dissipated heat')
boundary('hp-ambient-in', 'hp', 'in', ambient_heat, 'thermal_energy', 'outdoor air', 'heating outputs minus heating electricity; separate from cooling mode')
boundary('hp-rejection', 'hp', 'out', cooling_rejection, 'thermal_energy', 'outdoor air', 'heat removed from buildings plus cooling electricity')
boundary('tank-loss', 'tanks', 'out', tank_loss, 'thermal_energy', 'ambient environment', 'assumed 2% of delivered domestic hot-water heat')
boundary('battery-loss', 'battery', 'out', batt_loss, 'thermal_energy', 'ambient environment', 'charge minus discharge under equal beginning/end stored energy')
boundary('network-loss', 'network', 'out', network_loss, 'thermal_energy', 'ambient environment', 'screening allowance: 2% of PV generation, not hourly power-flow loss')
boundary('aux-release', 'aux', 'out', aux, 'thermal_energy', 'ambient environment')
boundary('utilities-release', 'utilities', 'out', municipal, 'thermal_and_other_energy', 'water and ambient environment',
         'aggregate dissipation closure; process/material enthalpy not separately characterized')
boundary('building-release', 'buildings', 'out', building_other_release, 'thermal_and_other_energy', 'air, wastewater and surrounding environment',
         'residual after explicit HVAC extraction; not an envelope or comfort simulation')
boundary('grid-net', 'grid', 'out', net_export, 'electricity', 'upstream electricity network', 'same annual net exchange, no duplicated generation credit')

# Validate numerical conservation from exported graph values, not duplicate formulas.
balances = defaultdict(lambda: {'input_mwh': 0.0, 'output_mwh': 0.0})
for f in flow_records:
    balances[f['source_twin']]['output_mwh'] += f['value']
    balances[f['target_twin']]['input_mwh'] += f['value']
for f in boundary_records:
    balances[f['asset_twin']]['input_mwh' if f['direction'] == 'in' else 'output_mwh'] += f['value']
balance_checks = []
for tid, b in sorted(balances.items()):
    residual = b['input_mwh'] - b['output_mwh']
    balance_checks.append({'twin_id': tid, **b, 'assumed_delta_energy_stock_mwh': 0.0,
                           'residual_mwh': round(residual, 8), 'pass': abs(residual) < 1e-6,
                           'meaning': 'arithmetic closure under stated assumptions; not independent performance validation'})

generation_kwp = (P['onsite_pv_mwp_dc'] + P['offsite_pv_mwp_dc']) * 1000
threshold_yield = (demand + batt_loss) * 1000 / (generation_kwp * (1 - P['network_loss_fraction_of_pv_generation']))
target_yield = (demand * (1 + P['design_surplus_fraction']) + batt_loss) * 1000 / (generation_kwp * (1 - P['network_loss_fraction_of_pv_generation']))
min_offsite = (demand * 1.1 + batt_loss) / (P['pv_yield_kwh_kwp_year'] * 0.98) - P['onsite_pv_mwp_dc']
scenarios = []
for label, y, factor in [('base', 1300, 1.0), ('solar_minus_10_percent', 1170, 1.0),
                         ('low_solar', 1000, 1.0), ('high_solar', 1600, 1.0),
                         ('demand_plus_25_percent', 1300, 1.25)]:
    g = generation_kwp * y / 1000
    d = demand * factor
    n = g * 0.98 - batt_loss - d
    scenarios.append({'id': label, 'yield_kwh_kwp_year': y, 'demand_multiplier': factor,
       'generation_mwh': g, 'demand_mwh': d, 'battery_loss_mwh': batt_loss, 'network_loss_mwh': g * 0.02,
       'net_export_mwh': round(n, 6), 'surplus_fraction_of_demand': round(n / d, 6),
       'net_positive': n > 0, 'ten_percent_margin': n >= d * .1,
       'limitation': 'one-variable screening; battery throughput held fixed; no hourly dispatch'})

eta_discharge = math.sqrt(P['battery_round_trip_efficiency'])
minimum_batt_stock = P['battery_nameplate_mwh'] * P['battery_minimum_soc']
full_batt_stock = P['battery_nameplate_mwh'] * P['battery_maximum_soc']
backup_initial = (P['battery_initial_stored_mwh'] - minimum_batt_stock) * eta_discharge * .98 / P['critical_load_mw']
backup_full = (full_batt_stock - minimum_batt_stock) * eta_discharge * .98 / P['critical_load_mw']

results = {'floor_area_m2': gfa, 'mean_storeys': gfa / P['building_footprint_m2'],
    'city_density_people_per_ha': P['population'] / (P['city_area_m2'] / 10000),
    'electricity_demand_mwh_year': demand, 'electricity_per_person_kwh_year': demand * 1000 / P['population'],
    'average_electricity_mw': demand / P['hours_per_year'], 'onsite_pv_mwh_year': pv_site,
    'offsite_pv_mwh_year': pv_shore, 'total_pv_mwh_year': generation, 'battery_loss_mwh_year': batt_loss,
    'network_loss_mwh_year': network_loss, 'net_export_mwh_year': net_export,
    'net_surplus_fraction': net_export / demand, 'onsite_generation_fraction_of_demand_before_losses': pv_site / demand,
    'city_only_net_import_mwh_year_with_local_loss_allowance': demand + batt_loss + pv_site * .02 - pv_site,
    'break_even_yield_kwh_kwp_year': threshold_yield, 'ten_percent_margin_yield_kwh_kwp_year': target_yield,
    'minimum_offsite_pv_mwp_for_ten_percent_margin': min_offsite,
    'all_platform_pv_mwh_year_geometric_screen': P['city_area_m2'] * P['pv_module_kwp_m2'] * P['pv_yield_kwh_kwp_year'] / 1000,
    'tank_heat_stock_mwh': tank_energy, 'tank_usable_heat_mwh': tank_usable,
    'battery_backup_hours_at_initial_soc': backup_initial, 'battery_backup_hours_at_maximum_soc': backup_full,
    'space_heat_electricity_mwh': heating_e, 'cooling_electricity_mwh': cooling_e,
    'dhw_electricity_mwh': hot_water_e, 'heating_electricity_saved_vs_resistance_mwh': space_heat + tank_charge - heating_e - hot_water_e,
    'heat_demand_mwh': space_heat, 'cooling_demand_mwh': cooling, 'hot_water_delivered_mwh': hot_water}

sources = [
 {'id': 'IEA-HP', 'title': 'IEA, The Future of Heat Pumps: How a heat pump works (2022)',
  'url': 'https://www.iea.org/reports/the-future-of-heat-pumps/how-a-heat-pump-works',
  'use': 'Heat-transfer principle and generic COP context. Does not verify the selected seasonal COPs.'},
 {'id': 'ATB-BESS', 'title': 'NREL 2024 Annual Technology Baseline: Commercial Battery Storage',
  'url': 'https://atb.nrel.gov/electricity/2024/commercial_battery_storage',
  'use': '85% representative round-trip efficiency; no manufacturer guarantee or cost estimate.'},
 {'id': 'PVWATTS', 'title': 'PVWatts cautions for interpreting results',
  'url': 'https://pvwatts.nlr.gov/docs/en/help_results_interpret.php',
  'use': 'Weather, shading and degradation uncertainty; no PVWatts simulation was run.'},
 {'id': 'LBNL-LAND', 'title': 'Bolinger and Bolinger, Land Requirements for Utility-Scale PV (2022)',
  'url': 'https://emp.lbl.gov/webinar/land-requirements-utility-scale-pv',
  'use': 'Land-use density depends on layout and technology; chosen 30 ha is a planning reservation, not a surveyed parcel or quoted benchmark.'},
 {'id': 'DOE-MARINE', 'title': 'DOE: Managing and Mitigating Solar PV Corrosion',
  'url': 'https://www.energy.gov/cmei/femp/managing-and-mitigating-solar-pv-corrosion',
  'use': 'Marine exposure requires corrosion-specific design and maintenance.'},
 {'id': 'AZURE', 'title': 'Microsoft Learn: Use Azure Digital Twins Explorer',
  'url': 'https://learn.microsoft.com/en-us/azure/digital-twins/how-to-use-azure-digital-twins-explorer',
  'use': 'JSON graph import/export and model upload workflow.'}
]

unknowns = [
 {'id': 'weather', 'status': 'unresolved', 'quantity': 'site weather and shading; measured/simulated annual PV yield', 'affected_check': 'generation reliability'},
 {'id': 'gross-grid', 'status': 'unresolved', 'twin_id': PREFIX + 'network', 'quantity': 'annual gross grid imports, exports and hourly dispatch', 'affected_check': 'self-sufficiency, peak and resilience'},
 {'id': 'load-profile', 'status': 'unresolved', 'quantity': 'hourly demand, occupancy, actual floor area, climate and municipal process loads', 'affected_check': 'annual demand and peak coincidence'},
 {'id': 'marine-structure', 'status': 'unresolved', 'quantity': 'hull displacement, stability, platform mass, equipment mass, moorings, wind/wave exposure', 'affected_check': 'floating-city structural feasibility'},
 {'id': 'shore-parcel', 'status': 'unresolved', 'quantity': 'available 30 ha offsite parcel, cable route and utility connection', 'affected_check': 'external dependency and spatial feasibility'},
 {'id': 'materials', 'status': 'unresolved', 'quantity': 'incorporated material stocks in all infrastructure; material mass and embodied energy', 'affected_check': 'life-cycle energy and carbon; excluded from operational goal'},
 {'id': 'green-stocks', 'status': 'unresolved', 'twin_id': PREFIX + 'courts', 'quantity': 'biomass, soil mass, irrigation, evapotranspiration and cooling effect', 'affected_check': 'green-infrastructure metabolism; no energy credit assigned'},
 {'id': 'water', 'status': 'unresolved', 'quantity': 'potable/wastewater throughput, desalination requirement and municipal pumping head', 'affected_check': 'municipal electricity allowance; water service balance outside scope'},
 {'id': 'economics', 'status': 'unresolved', 'quantity': 'marine installation cost, tariffs, export revenue, finance, O&M and household affordability', 'affected_check': 'economic feasibility and optimum size'},
 {'id': 'social-environmental', 'status': 'unresolved', 'quantity': 'access to shore land, ecological impacts, distribution of benefits, noise and emergency access', 'affected_check': 'social and environmental feasibility'},
 {'id': 'hourly-resilience', 'status': 'unresolved', 'quantity': 'storm/outage duration, critical-load profile and state of charge at outage', 'affected_check': 'reliable backup; full-city islanding not demonstrated'},
 {'id': 'stock-closure', 'status': 'assumed_not_measured', 'quantity': 'equal beginning/end energy stocks for annual non-storage assets; battery/tank equal end state', 'affected_check': 'annual energy accounting'},
]

ledger = {'schema_version': '1.0', 'scenario_id': SYSTEM, 'brief': {'city_area_ha': 6.3, 'population': 12000, 'location': 'unspecified'},
 'accounting': {'period': PERIOD, 'goal': 'renewable AC electricity exceeds all modeled operating electricity and electrical losses over one year',
  'design_margin_fraction': .1, 'city_boundary': '6.3 ha floating platforms only',
  'project_boundary': 'city plus dedicated 18 MWp onshore PV and connection infrastructure',
  'renewable_attributes': 'Must be retained exclusively; no duplicate claims or unbundled certificate substitute modeled.',
  'excluded_services': ['construction and embodied energy', 'offsite transport/ferries', 'industrial production', 'energy-intensive indoor agriculture'],
  'thermal_accounting': 'Thermal exchanges are separately balanced; ambient heat is not added to the renewable-electricity numerator.',
  'metering': 'PV generation is AC after plant inverter/system losses; 2% network loss is additional. Net grid flow is exports minus imports.',
  'scope_limit': 'Operational annual energy concept, not proof of autonomy, life-cycle positivity or floating-city constructibility.'},
 'schema_limitations': [
  'Agreed stock/flow maps contain only numeric value and unit. Timing, carrier, capacity, evidence and boundary status are in this linked ledger.',
  'Natural sunlight/ambient-air exchanges have no physical asset twin endpoint: boundary_transfers records them without invented resource/loss nodes.',
  'Unknown quantities remain unresolved records; absent stock maps are not zero stocks.',
  'The tanks contain a sealed buffer-water mass: thermal transfer to domestic hot water crosses a heat exchanger; potable mass flows belong to a future water model.'
 ], 'assumptions': P, 'asset_records': assets, 'stock_records': stock_records, 'flow_records': flow_records,
 'boundary_transfers': boundary_records, 'heat_pump_mode_breakdown_mwh_year': {
  'space_heating': {'electricity_in': heating_e, 'ambient_heat_in': space_heat - heating_e, 'heat_out': space_heat},
  'hot_water': {'electricity_in': hot_water_e, 'ambient_heat_in': tank_charge - hot_water_e, 'heat_out': tank_charge},
  'cooling': {'electricity_in': cooling_e, 'heat_removed_in': cooling, 'heat_rejected_out': cooling_rejection}},
 'asset_energy_balances': balance_checks, 'results': results, 'sensitivity': scenarios,
 'revision': {'initial_candidate': '4.2 MWp onsite PV only', 'result': 'fails annual net-positive electricity goal',
  'selected_candidate': 'efficient electric buildings, 4.2 MWp onsite PV, 18 MWp onshore PV, 5 MW/20 MWh battery, 250 m3 hot-water buffers',
  'method': 'manual screening and joint adjustment of demand, area and generation; no optimization solver or cost-optimality claim'},
 'corrective_sizing_options': {
  'offsite_pv_mwp_at_1000_yield_for_ten_percent_margin': (demand * 1.1 + batt_loss) / (1000 * .98) - P['onsite_pv_mwp_dc'],
  'offsite_pv_mwp_at_25_percent_higher_demand_for_ten_percent_margin': (demand * 1.25 * 1.1 + batt_loss) / (1300 * .98) - P['onsite_pv_mwp_dc'],
  'interpretation': 'Conditional resizing calculations, not selected or constructed assets. Additional external land would be required.'},
 'unresolved': unknowns, 'sources': sources}

graph = {'digitalTwinsFileInfo': {'fileVersion': '1.0.0'}, 'digitalTwinsModels': [],
         'digitalTwinsGraph': {'digitalTwins': twins, 'relationships': relationships}}
save('graph.json', graph)
save('twins.json', twins)
save('relationships.json', relationships)
save('ledger.json', ledger)

# Local structural checks, against the actual bundled definitions and serialized outputs.
declared_ids = {m['@id'] for m in MODELS}
assert declared_ids == {f'dtmi:environmental:{r};3' for r in ['Twin', 'InputTwin', 'ProcessTwin', 'OutputTwin']}
assert all(m['@context'] == 'dtmi:dtdl:context;2' for m in MODELS)
ids = {t['$dtId'] for t in twins}
assert len(ids) == len(twins)
assert len({(r['$sourceId'], r['$relationshipId']) for r in relationships}) == len(relationships)
for t in twins:
    assert t['$metadata']['$model'] in declared_ids
    assert set(t) == {'$dtId', '$metadata', 'name', 'system', 'stock'}
    assert isinstance(t['name'], str) and isinstance(t['system'], str)
    for value in t['stock'].values():
        assert set(value) == {'value', 'unit'} and isinstance(value['unit'], str) and math.isfinite(value['value'])
    assert t['$dtId'] not in {'storage', 'consumption', 'efficiency'}
for r in relationships:
    assert r['$sourceId'] in ids and r['$targetId'] in ids
    if r['$relationshipName'] == 'flowsTo':
        assert set(r) == {'$relationshipId', '$sourceId', '$targetId', '$relationshipName', 'name', 'system', 'flow'}
        assert r['flow']
        for v in r['flow'].values():
            assert set(v) == {'value', 'unit'} and isinstance(v['unit'], str) and math.isfinite(v['value'])
    else:
        assert r['$relationshipName'] == 'contains'
        assert set(r) == {'$relationshipId', '$sourceId', '$targetId', '$relationshipName'}
children = defaultdict(list)
for r in relationships:
    if r['$relationshipName'] == 'contains': children[r['$sourceId']].append(r['$targetId'])
def no_cycle(tid, visiting):
    assert tid not in visiting
    for c in children[tid]: no_cycle(c, visiting | {tid})
for tid in ids: no_cycle(tid, set())
tmap, rmap = {t['$dtId']: t for t in twins}, {r['$relationshipId']: r for r in relationships}
for s in stock_records:
    assert tmap[s['twin_id']]['stock'][s['stock_key']] == {k: s[k] for k in ['value', 'unit']}
    assert abs(s['end_value'] - s['value'] - s['delta']) < 1e-8
for f in flow_records:
    assert rmap[f['relationship_id']]['flow'][f['flow_key']] == {k: f[k] for k in ['value', 'unit']}
    assert f['period_id'] == PERIOD['id']
assert all(c['pass'] for c in balance_checks)
assert abs(P['building_footprint_m2'] + P['public_space_m2'] + P['planted_courts_m2'] + P['utility_compound_m2'] - P['city_area_m2']) < 1e-8
assert 18000 <= P['building_footprint_m2'] and 3000 <= P['public_space_m2']
assert pv_shore_area < P['offsite_pv_land_m2']
assert minimum_batt_stock <= P['battery_initial_stored_mwh'] <= full_batt_stock
assert P['thermal_tank_minimum_c'] <= P['thermal_tank_initial_c'] <= P['thermal_tank_maximum_c']
global_residual = sum(b['value'] if b['direction'] == 'in' else -b['value'] for b in boundary_records)
assert abs(global_residual) < 1e-6
assert abs(generation - demand - batt_loss - network_loss - net_export) < 1e-6
for f in ['graph.json', 'twins.json', 'relationships.json', 'ledger.json', 'model.json', 'scenario.json']:
    json.loads((ROOT / f).read_text(), parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
validation = {'status': 'local_checks_passed', 'twins': len(twins), 'relationships': len(relationships),
  'flow_relationships_with_numeric_maps': len(flow_records), 'populated_stock_quantities': len(stock_records),
  'boundary_transfer_records': len(boundary_records), 'asset_energy_balances_checked': len(balance_checks),
  'global_energy_residual_mwh': round(global_residual, 8), 'annual_net_positive': net_export > 0,
  'ten_percent_margin': net_export >= demand * .1, 'strict_city_only_net_positive': False,
  'checks': ['valid JSON and finite quantities', 'exact agreed model references', 'declared inherited property shapes',
   'unique IDs and existing endpoints', 'acyclic containment', 'graph-ledger numerical agreement',
   'asset and boundary annual energy conservation', 'area allocation arithmetic', 'stock operating bounds'],
  'not_performed': ['official Microsoft DTDL parser validation', 'live Azure import', '8760-hour weather/load/storage simulation',
   'network peak/load-flow calculation', 'marine structural verification', 'economic optimization', 'life-cycle or emissions assessment'],
  'results': results, 'sensitivity': scenarios}
save('validation.json', validation)
print(json.dumps(validation, indent=2))
