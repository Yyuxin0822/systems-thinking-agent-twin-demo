#!/usr/bin/env python3
"""Integrated annual concept balances. Python standard library; not a simulation."""
from pathlib import Path
from collections import defaultdict
import json, math
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'scenario.json').read_text())
def save(name,data): (ROOT/name).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
D=P['days']; N=P['population']
consumed=P['consumed_food_t_year']
city_food={k:v/(1-P['city_food_loss_fraction']) for k,v in consumed.items()}
export_food={k:v*P['food_export_fraction_of_city_supply'] for k,v in city_food.items()}
garden_t=P['garden_area_m2']*P['garden_yield_kg_m2_year']/1000
farm_food={k:city_food[k]+export_food[k]-(garden_t if k=='produce' else 0) for k in consumed}
farm_area={k:v/P['farm_net_yield_t_ha_year'][k] for k,v in farm_food.items()}
farm_ha=sum(farm_area.values()); farm_gross_ha=farm_ha*P['farm_gross_land_multiplier']
food_city_t=sum(city_food.values()); food_export_t=sum(export_food.values()); farm_food_t=sum(farm_food.values())
farm_gross_food={k:v/(1-P['farm_food_processing_loss_fraction']) for k,v in farm_food.items()}
farm_gross_food_t=sum(farm_gross_food.values())
food_processing_residue=farm_gross_food_t-farm_food_t
food_waste=food_city_t-sum(consumed.values())
diet_kcal=sum(consumed[k]*1000*P['food_kcal_kg'][k] for k in consumed)-garden_t*(1-P['city_food_loss_fraction'])*1000*(P['food_kcal_kg']['produce']-P['garden_leafy_kcal_kg'])
diet_protein=sum(consumed[k]*P['food_protein_fraction'][k] for k in consumed)
diet_fat=sum(consumed[k]*P['food_fat_fraction'][k] for k in consumed)
food_kcal_city_in=sum(city_food[k]*1000*P['food_kcal_kg'][k] for k in consumed)-garden_t*1000*(400-P['garden_leafy_kcal_kg'])
food_kcal_export=sum(export_food[k]*1000*P['food_kcal_kg'][k] for k in consumed)

# Managed water, m3/year. The freshwater/reuse loops are separated.
garden_water=garden_t*P['garden_water_l_kg']
potable_house=P['household_potable_m3_day']*D
fresh_export=P['potable_export_m3_day']*D
fresh_delivered=potable_house+garden_water+fresh_export
ro_product=fresh_delivered/(1-P['distribution_loss_fraction'])
fresh_loss=ro_product-fresh_delivered
ro_feed=ro_product/P['ro_recovery_fraction']; ro_brine=ro_feed-ro_product
salt_in=ro_feed*P['seawater_salt_kg_m3']/1000
salt_product=ro_product*P['product_salt_kg_m3']/1000
salt_brine=salt_in-salt_product
reuse_house=P['household_reuse_m3_day']*D
sewer=(potable_house+reuse_house)*P['household_sewer_return_fraction']
house_water_loss=potable_house+reuse_house-sewer
reclaimed=sewer*P['ww_reclaimed_recovery_fraction']
sludge_water=P['ww_sludge_water_m3_day']*D
ww_evap=sewer-reclaimed-sludge_water
rain=P['rain_roof_area_m2']*P['city_rainfall_m_year']*P['rain_capture_fraction']
courts_water=P['court_irrigation_m3_day']*D; cleaning_water=P['public_cleaning_m3_day']*D
reuse_city_delivered=reuse_house+courts_water+cleaning_water
reuse_city_with_loss=reuse_city_delivered/(1-P['distribution_loss_fraction'])
reuse_loss=reuse_city_with_loss-reuse_city_delivered
farm_reuse=reclaimed+rain-reuse_city_with_loss
farm_irrigation=farm_ha*P['farm_irrigation_m3_ha_year']
reservoir_evap=P['reservoir_evaporation_m3_year']
farm_capture=farm_irrigation+reservoir_evap-farm_reuse
farm_rain=farm_ha*10000*P['farm_rainfall_m_year']
farm_et=farm_ha*10000*P['farm_et_m_year']
farm_crop_water=sum(farm_food[k]*{'grain':0.12,'pulses':0.12,'oil':0,'roots':0.8,'produce':0.9}[k] for k in farm_food)
farm_drain=farm_rain+farm_irrigation-farm_et-farm_capture-farm_crop_water

# Solid-waste outputs are actual recovery products or biological-treatment inputs.
organics=food_waste+P['court_green_waste_t_year']
P['solid_waste_t_year']=P['nonfood_discard_t_year']+organics
ad_organics=organics*P['organics_capture_fraction']
ad_all_organics=ad_organics+food_processing_residue
uncaptured_organics=organics-ad_organics
sort_in=P['dry_recyclables_t_year']*P['recyclables_capture_fraction']
sort_product=sort_in*P['sorter_product_yield']; sort_reject=sort_in-sort_product
reusable_in=P['reusable_goods_t_year']; reused=reusable_in*P['repair_product_yield']; repair_reject=reusable_in-reused
intrinsic_residual=P['solid_waste_t_year']-organics-P['dry_recyclables_t_year']-reusable_in
collection_residual=intrinsic_residual+uncaptured_organics+P['dry_recyclables_t_year']-sort_in
city_residual=collection_residual+sort_reject+repair_reject
diversion=1-city_residual/P['solid_waste_t_year']

# Non-food goods steady stock. Recovered materials are not universally fungible.
nonfood_discard=P['solid_waste_t_year']-organics
new_goods=nonfood_discard-reused
factory_feed=new_goods/P['factory_yield']
secondary_used=factory_feed*P['goods_recycled_content']; virgin=factory_feed-secondary_used
secondary_export=sort_product-secondary_used
factory_reject=factory_feed-new_goods

# Co-digestion screen. Wet mass, VS yield, methane, nitrogen and phosphorus.
sludge_dry=P['ww_sludge_dry_kg_person_day']*N*D/1000
sludge_wet=sludge_water+sludge_dry
ad_feed=sludge_wet+ad_all_organics
vs=sludge_dry*P['sludge_vs_fraction_dry']+ad_all_organics*(1-P['organics_water_fraction'])*P['organics_vs_fraction_dry']
methane=vs*1000*P['methane_nm3_kg_vs_fed']
biogas=methane/P['biogas_methane_volume_fraction']; co2_volume=biogas-methane
methane_mass=methane*P['methane_density_kg_nm3']/1000
co2_mass=co2_volume*P['co2_density_kg_nm3']/1000
leak_mass=methane_mass*P['methane_leak_fraction']
burn_mass=methane_mass-leak_mass
fuel_mwh=methane*(1-P['methane_leak_fraction'])*P['methane_lhv_kwh_nm3']/1000
boiler_heat=fuel_mwh*P['boiler_efficiency']; boiler_stack_loss=fuel_mwh-boiler_heat
heat_duty=P['digester_heat_mwh_year']+P['food_process_heat_mwh_year']
heat_surplus=boiler_heat-heat_duty
food_n_waste=(diet_protein/6.25)/(1-P['city_food_loss_fraction'])*P['city_food_loss_fraction']
processing_n=sum((farm_gross_food[k]-farm_food[k])*P['food_protein_fraction'][k]/6.25 for k in farm_food)
ad_n=(food_n_waste+P['court_green_waste_t_year']*P['prunings_n_fraction_wet'])*P['organics_capture_fraction']+sludge_dry*P['sludge_n_fraction_dry']+processing_n
ad_p=ad_all_organics*P['organics_p_fraction_wet']+sludge_dry*P['sludge_p_fraction_dry']
digestate_n=ad_n*P['digester_n_retention']; n_loss=ad_n-digestate_n
ammonia_loss_mass=n_loss*17/14
digestate=ad_feed-methane_mass-co2_mass-ammonia_loss_mass
n_available=digestate_n*P['fertilizer_n_first_year_availability']
p_available=ad_p*P['fertilizer_p_first_year_availability']
farm_n_need=farm_ha*P['farm_n_demand_kg_ha_year']/1000
farm_p_need=farm_ha*P['farm_p_demand_kg_ha_year']/1000

# Expanded electricity demand replaces the prior generic municipal allowance.
loads={
 'buildings':P['base_non_hvac_mwh_year'], 'hp':P['base_hp_mwh_year'], 'aux':P['base_aux_mwh_year'],
 'ro':ro_product*P['ro_kwh_m3_product']/1000,
 'ww':sewer*P['ww_kwh_m3_influent']/1000,
 'fresh':ro_product*P['water_distribution_kwh_m3']/1000,
 'reuse':(reclaimed+rain)*P['water_distribution_kwh_m3']/1000,
 'rain':rain*P['rain_treatment_kwh_m3']/1000,
 'garden':garden_t*P['garden_electricity_kwh_kg'],
 'farms':farm_ha*P['farm_field_electricity_kwh_ha_year']/1000+farm_irrigation*P['farm_irrigation_kwh_m3']/1000,
 'food':(farm_gross_food_t+garden_t)*P['food_handling_kwh_t']/1000,
 'digester':ad_feed*P['digester_kwh_t_wet']/1000,
 'collection':P['solid_waste_t_year']*P['collection_kwh_t']/1000,
 'sorter':sort_in*P['sorting_kwh_t']/1000,
 'repair':reusable_in*P['repair_kwh_t']/1000,
 'factory':factory_feed*P['factory_kwh_t_processed']/1000,
 'freight':P['freight_mwh_year']}
demand=sum(loads.values())
onsite_pv=P['rooftop_pv_mwp']*P['pv_yield_kwh_kwp_year']; shore_pv=P['shore_pv_mwp']*P['pv_yield_kwh_kwp_year']
pv=onsite_pv+shore_pv; network_loss=pv*P['network_loss_fraction']
battery_in=P['battery_charge_mwh_day']*D; battery_out=battery_in*P['battery_rte']; battery_loss=battery_in-battery_out
net=pv-demand-network_loss-battery_loss

R={
 'food_city_supply_t_year':food_city_t,'food_consumed_t_year':sum(consumed.values()),'food_exports_t_year':food_export_t,
 'food_city_kcal_year':food_kcal_city_in,'food_consumed_kcal_year':diet_kcal,'food_exports_kcal_year':food_kcal_export,
 'food_consumed_kcal_person_day':diet_kcal/N/D,'food_protein_g_person_day':diet_protein*1e6/N/D,'food_fat_g_person_day':diet_fat*1e6/N/D,
 'food_waste_t_year':food_waste,'garden_food_t_year':garden_t,'farm_net_food_t_year':farm_food_t,
 'farm_gross_food_t_year':farm_gross_food_t,'food_processing_residue_t_year':food_processing_residue,
 'farm_productive_ha':farm_ha,'farm_gross_ha':farm_gross_ha,'farm_area_by_crop_ha':farm_area,
 'potable_product_m3_day':ro_product/D,'potable_export_m3_day':fresh_export/D,'ro_seawater_m3_day':ro_feed/D,
 'ro_brine_m3_day':ro_brine/D,'ro_brine_salt_kg_m3':salt_brine*1000/ro_brine,'reclaimed_m3_day':reclaimed/D,
 'farm_reuse_m3_day':farm_reuse/D,'rain_captured_m3_year':rain,'ww_influent_m3_day':sewer/D,
 'farm_irrigation_m3_year':farm_irrigation,'farm_runoff_capture_m3_year':farm_capture,'farm_rain_m3_year':farm_rain,
 'farm_et_m3_year':farm_et,'farm_other_drainage_m3_year':farm_drain,
 'waste_generated_t_year':P['solid_waste_t_year'],'waste_diversion_fraction':diversion,
 'city_residual_t_year':city_residual,'ad_organics_t_year':ad_organics,'recycled_output_t_year':sort_product,'reused_t_year':reused,
 'new_goods_t_year':new_goods,'virgin_feedstock_t_year':virgin,'secondary_export_t_year':secondary_export,'factory_reject_t_year':factory_reject,
 'ad_feed_t_year':ad_feed,'methane_nm3_year':methane,'methane_leak_t_year':leak_mass,'digestate_t_year':digestate,
 'biogas_heat_mwh_year':boiler_heat,'biogas_heat_used_mwh_year':heat_duty,'biogas_heat_surplus_mwh_year':heat_surplus,
 'digestate_n_t_year':digestate_n,'digestate_p_t_year':ad_p,'first_year_available_n_t':n_available,'first_year_available_p_t':p_available,
 'farm_n_requirement_t_year':farm_n_need,'farm_p_requirement_t_year':farm_p_need,
 'farm_additional_n_supply_required_t_year':farm_n_need-n_available,'farm_additional_p_supply_required_t_year':farm_p_need-p_available,
 'electricity_loads_mwh_year':loads,'electricity_demand_mwh_year':demand,'pv_generation_mwh_year':pv,
 'battery_loss_mwh_year':battery_loss,'network_loss_mwh_year':network_loss,'net_electricity_export_mwh_year':net,
 'energy_surplus_fraction':net/demand,'shore_pv_ha':P['shore_pv_mwp']*P['shore_pv_land_ha_mwp']}
save('results.json',R)
PREFIX='fc63x-'; PERIOD='design_year_1'
T=[]; E=[]; A=[]; S=[]; F=[]; B=[]
def Q(v,u): return {'value':round(float(v),9),'unit':u}
def asset(key,name,role,system,place,description,stocks=None,capacities=None):
    stocks=stocks or {}
    T.append({'$dtId':PREFIX+key,'$metadata':{'$model':f'dtmi:environmental:{role}Twin;3'},
      'name':name,'system':system,'stock':stocks})
    A.append({'twin_id':PREFIX+key,'asset_description':description,'location':place,
      'status':'proposed_or_dedicated_allocation_not_secured','capacities':capacities or {},
      'unquantified_stock':'Construction materials and equipment mass are unresolved unless specifically populated.'})
    for k,v in stocks.items():
        S.append({'twin_id':PREFIX+key,'stock_key':k,**v,'reference_time':'design_year_start',
          'end_reference_time':'design_year_end','end_value':v['value'],'delta':0.0,
          'evidence':'explicit design snapshot assumption; periodic annual state, not a measurement'})
def flow(key,src,dst,label,system,quantities,method='calculated from explicit concept assumptions',kind='annual_total'):
    rid=PREFIX+key
    E.append({'$relationshipId':rid,'$sourceId':PREFIX+src,'$targetId':PREFIX+dst,
      '$relationshipName':'flowsTo','name':label,'system':system,'flow':quantities})
    for k,v in quantities.items():
        F.append({'source_twin':PREFIX+src,'relationship_id':rid,'target_twin':PREFIX+dst,
          'flow_key':k,**v,'period_id':PERIOD,'time_basis':'total_over_365_days','aggregation':kind,'evidence':method})
def boundary(key,who,direction,quantities,label,status='assumption_or_calculation'):
    for k,v in quantities.items():
        B.append({'id':key+'-'+k,'asset_twin':PREFIX+who,'direction':direction,'quantity_key':k,**v,
          'external_domain_or_conversion':label,'period_id':PERIOD,'time_basis':'total_over_365_days',
          'evidence_status':status,'schema_route':'linked ledger; not an abstract-resource twin'})
def contains(parent,child):
    E.append({'$relationshipId':PREFIX+'has-'+parent+'-'+child,'$sourceId':PREFIX+parent,
      '$targetId':PREFIX+child,'$relationshipName':'contains'})

asset('city','City','Process','integrated','city','Floating platforms, buildings and their onsite infrastructure.',capacities={'area':Q(63000,'m2'),'residents':Q(N,'person')})
asset('buildings','Buildings','Output','integrated','city','Occupied building assemblies, household fixtures and equipment.',capacities={'floor_area':Q(P['gfa_m2'],'m2'),'footprint':Q(35000,'m2'),'mean_storeys':Q(12,'storey')})
asset('pv','Roof PV','Input','energy','city','Rooftop and canopy modules and inverters.',capacities={'dc_power':Q(P['rooftop_pv_mwp'],'MWp'),'module_area':Q(21000,'m2')})
asset('shore-pv','Shore PV','Input','energy','shore','Dedicated onshore PV plant, retaining its generation attributes.',capacities={'dc_power':Q(P['shore_pv_mwp'],'MWp'),'land':Q(R['shore_pv_ha'],'ha')})
asset('network','Power Link','Process','energy','city_and_shore','Submarine cable, shore hub and city distribution switchgear.',capacities={'city_link':Q(15,'MVA'),'shore_hub':Q(30,'MVA'),'status':'placeholder; no load flow or contingency sizing'})
asset('battery','Battery','Process','energy','city','Battery racks, enclosures and bidirectional converters.',{'storedEnergy':Q(10,'MWh')},{'energy':Q(20,'MWh'),'power':Q(5,'MW'),'minimum_stock':Q(2,'MWh'),'maximum_stock':Q(18,'MWh')})
asset('hp','Heat Pumps','Process','energy','city','Reversible air-source units and domestic hot-water heat pumps.',capacities={'space_heat':Q(16.8,'MW_thermal'),'cooling':Q(14.7,'MW_thermal'),'hot_water':Q(4,'MW_thermal')})
asset('hot-tanks','Hot Tanks','Process','energy','city','Sealed hot-water buffer tanks and heat exchangers.',{'waterMass':Q(250000,'kg'),'storedHeat':Q(11.611111111,'MWh')},{'volume':Q(250,'m3'),'snapshot_temperature':Q(60,'degC'),'reference_temperature':Q(20,'degC'),'usable_45_to_65_C':Q(5.805555556,'MWh')})
asset('aux','Plant Aux','Process','energy','city','Circulation pumps, sensors, controls and energy-management controller hardware.')
asset('courts','Shade Courts','Process','water','city','Planted court assemblies, irrigation emitters and public cleaning equipment.',capacities={'planting_area':Q(6000,'m2'),'cleaning_area':'part of 17,000 m2 public circulation; no double land allocation'})
asset('grid','Grid Station','Output','energy','outside_project','Utility substation for gross imports and exports; annual net exchange only is quantified.')
asset('ro','Water Works','Process','water','shore','Seawater intake, pretreatment, RO, remineralization and disinfection plant.',capacities={'product_capacity':Q(1200,'m3/day'),'configuration':'3 x 600 m3/day skids, two duty and one standby; intake and quality sizing unverified'})
asset('fresh','Fresh Tanks','Process','water','city_and_shore','Potable reservoirs, city day tanks and distribution pumps.',{'storedWater':Q(1800,'m3'),'dissolvedSalt':Q(0.36,'t')},{'total_volume':Q(3000,'m3'),'city_volume':Q(600,'m3'),'city_snapshot_water':Q(450,'m3'),'shore_volume':Q(2400,'m3')})
asset('rain','Rain Cistern','Process','water','city','Roof collectors, first-flush devices, treatment and rainwater tank.',{'storedWater':Q(200,'m3')},{'tank_capacity':Q(500,'m3'),'roof_catchment':Q(35000,'m2')})
asset('ww','Water Reuse','Process','water','shore','Wastewater collection, nutrient treatment, membrane filtration, disinfection and sludge handling.',capacities={'capacity':Q(1500,'m3/day'),'configuration':'3 x 750 m3/day treatment trains, two duty, one standby; removal and pathogen targets unresolved'})
asset('reuse','Reuse Tank','Process','water','city_and_shore','Reclaimed-water reservoirs, separate pipe network and pumping.',{'storedWater':Q(500,'m3')},{'capacity':Q(1000,'m3'),'city_day_tank_capacity':Q(300,'m3')})
asset('reservoir','Farm Reservoir','Process','water','regional_farms','Covered where practical or managed open irrigation reservoir and collection works.',{'storedWater':Q(300000,'m3')},{'capacity':Q(500000,'m3'),'approx_water_area_at_4m':Q(12.5,'ha'),'land_accounting':'within farm 20% buffer/rotation reservation'})
asset('garden','Food Garden','Process','food','city','Sunlit seasonal growing beds, passive shelters and irrigation loops; no LED growing rooms.',{'nutrientSolution':Q(40,'m3')},{'growing_area':Q(4000,'m2'),'roof_allocation':'separate from 18,000 m2 roof PV; canopy PV uses another 3,000 m2'})
asset('farms','Food Farms','Process','food','regional_farms','Identifiable contracted cereal, pulse, oilseed, root and produce fields with electric equipment.',capacities={'productive_area':Q(farm_ha,'ha'),'gross_area':Q(farm_gross_ha,'ha'),'gross_includes':'20% additional rotation, reservoir and ecological buffers'})
asset('food','Food Hub','Process','food','city_and_shore','Food-processing, distribution and cold-store buildings.',{'edibleFood':Q(220,'t')},{'storage_capacity':Q(300,'t'),'city_food_stock':Q(40,'t'),'shore_food_stock':Q(180,'t')})
asset('collection','Waste Dock','Process','waste','city','Segregated collection bays and sealed containers at the service dock.',{'heldWaste':Q(15,'t')},{'capacity':Q(30,'t'),'normal_daily_throughput':Q(P['solid_waste_t_year']/D,'t/day')})
asset('sorter','Sort Plant','Process','materials','shore','Dry-recyclables sorting and baling equipment.',{'heldRecyclables':Q(10,'t')},{'throughput_capacity':Q(10,'t/day')})
asset('repair','Repair Hub','Process','materials','city_and_shore','Repair workshops and component reuse store.',{'heldGoods':Q(20,'t')},{'working_capacity':Q(50,'t')})
asset('factory','Manufacturers','Process','materials','regional_industry','Dedicated allocation of regional remanufacturing and materials-processing assets.',{'finishedGoods':Q(40,'t')},{'recycled_content_target':Q(.70,'fraction'),'grade_compatibility':'unresolved; aggregate mass screen does not prove interchangeable materials'})
asset('digester','Digesters','Process','waste','shore','Two mesophilic digesters, receiving tanks, gas holder and gas conditioning.',{'heldSlurry':Q(500,'t'),'heldMethane':Q(80,'Nm3')},{'reactor_volume':Q(600,'m3'),'configuration':'2 x 300 m3; nominal 25-day HRT requires about 385 m3','receiving_capacity':Q(25,'t/day')})
asset('boiler','Biogas Boiler','Process','energy','shore','Biogas-fired hot-water boiler and short local process-heat pipe loop.',capacities={'thermal_power':Q(.5,'MW_thermal'),'efficiency':Q(.85,'fraction')})
asset('digestate','Nutrient Tanks','Process','waste','shore','Covered digestate storage, sanitation and land-application equipment.',{'wetDigestate':Q(1000,'t'),'totalNitrogen':Q(1000*digestate_n/digestate,'t'),'totalPhosphorus':Q(1000*ad_p/digestate,'t')},{'storage_capacity':Q(2500,'m3'),'release_condition':'pathogens, contaminants, salinity and agronomic suitability must pass before application'})
asset('freight','Cargo Fleet','Process','energy','city_and_region','Allocated electric cargo vessels and delivery vehicles.',capacities={'annual_electricity_budget':Q(500,'MWh/year'),'route_and_fleet_sizing':'unresolved'})
asset('market','Shore Market','Output','food','outside_project','Receiving food cooperative warehouse for contracted edible surplus.')
asset('water-recipient','Shore Utility','Output','water','outside_project','Receiving utility reservoir for beneficial freshwater exports.')
asset('buyers','Material Buyers','Output','materials','outside_project','Receiving warehouses and processors for surplus secondary materials.')
asset('disposal','Residual Facility','Output','waste','outside_project','Permitted regional disposal facility for unavoidable residuals and rejects.')
for c in ['buildings','pv','battery','hp','hot-tanks','aux','courts','rain','garden','collection']: contains('city',c)

# Energy relationships.
flow('pv-power','pv','network','PV power','energy',{'electricity':Q(onsite_pv,'MWh')})
flow('shore-power','shore-pv','network','PV power','energy',{'electricity':Q(shore_pv,'MWh')})
flow('battery-charge','network','battery','Charge','energy',{'electricity':Q(battery_in,'MWh')})
flow('battery-discharge','battery','network','Discharge','energy',{'electricity':Q(battery_out,'MWh')})
for k,value in loads.items(): flow('power-'+k,'network',k,'Electricity','energy',{'electricity':Q(value,'MWh')})
flow('grid-net','network','grid','Net grid exchange','energy',{'netElectricity':Q(net,'MWh')},kind='exports_minus_imports')
flow('space-heat','hp','buildings','Space heat','energy',{'heat':Q(10500,'MWh')})
flow('cooling','buildings','hp','Heat removed','energy',{'heat':Q(6300,'MWh')})
flow('hot-charge','hp','hot-tanks','Hot-water charge','energy',{'heat':Q(8935.2,'MWh')})
flow('hot-delivery','hot-tanks','buildings','Hot-water heat','energy',{'heat':Q(8760,'MWh')})
flow('gas','digester','boiler','Conditioned biogas','energy',{'methane':Q(methane*(1-P['methane_leak_fraction']),'Nm3'),'fuelEnergy':Q(fuel_mwh,'MWh'),'gasMass':Q(burn_mass+co2_mass,'t')})
flow('ad-heat','boiler','digester','Digester heat','energy',{'heat':Q(P['digester_heat_mwh_year'],'MWh')})
flow('food-heat','boiler','food','Food-process heat','energy',{'heat':Q(P['food_process_heat_mwh_year'],'MWh')})

# Water relationships; embedded moisture is kept separate from managed pipe-water.
flow('fresh-product','ro','fresh','Treated freshwater','water',{'water':Q(ro_product,'m3'),'dissolvedSalt':Q(salt_product,'t')})
flow('potable-house','fresh','buildings','Potable supply','water',{'water':Q(potable_house,'m3')})
flow('potable-garden','fresh','garden','Garden makeup','water',{'water':Q(garden_water,'m3')})
flow('potable-export','fresh','water-recipient','Freshwater export','water',{'water':Q(fresh_export,'m3')})
flow('sewer','buildings','ww','Wastewater','water',{'water':Q(sewer,'m3')})
flow('reclaimed','ww','reuse','Reclaimed water','water',{'water':Q(reclaimed,'m3')})
flow('rainwater','rain','reuse','Treated rainwater','water',{'water':Q(rain,'m3')})
flow('reuse-house','reuse','buildings','Non-potable supply','water',{'water':Q(reuse_house,'m3')})
flow('reuse-courts','reuse','courts','Irrigation and cleaning','water',{'water':Q(courts_water+cleaning_water,'m3')})
flow('farm-reuse','reuse','reservoir','Irrigation makeup','water',{'water':Q(farm_reuse,'m3')})
flow('farm-runoff','farms','reservoir','Captured runoff','water',{'water':Q(farm_capture,'m3')})
flow('irrigation','reservoir','farms','Irrigation supply','water',{'water':Q(farm_irrigation,'m3')})
flow('sludge','ww','digester','Wastewater sludge','waste',{'wetMass':Q(sludge_wet,'t'),'containedWater':Q(sludge_water,'m3'),'drySolids':Q(sludge_dry,'t'),'totalNitrogen':Q(sludge_dry*P['sludge_n_fraction_dry'],'t'),'totalPhosphorus':Q(sludge_dry*P['sludge_p_fraction_dry'],'t')})

# Food and material conversion chains.
flow('harvest','farms','food','Harvested food','food',{'foodMass':Q(farm_gross_food_t,'t')},'net crop yields divided by 95% postharvest retention; field production is an assumed source term')
flow('garden-harvest','garden','food','Garden harvest','food',{'foodMass':Q(garden_t,'t'),'dietaryEnergy':Q(garden_t*1000*P['garden_leafy_kcal_kg'],'kcal')})
flow('food-house','food','buildings','Food supply','food',{'foodMass':Q(food_city_t,'t'),'dietaryEnergy':Q(food_kcal_city_in,'kcal')})
flow('food-export','food','market','Edible food surplus','food',{'foodMass':Q(food_export_t,'t'),'dietaryEnergy':Q(food_kcal_export,'kcal')})
flow('food-residue','food','digester','Processing residues','waste',{'wetMass':Q(food_processing_residue,'t'),'totalNitrogen':Q(processing_n,'t'),'totalPhosphorus':Q(food_processing_residue*P['organics_p_fraction_wet'],'t')})
flow('house-waste','buildings','collection','Source-separated discards','waste',{'wetMass':Q(food_waste+nonfood_discard,'t'),'foodWaste':Q(food_waste,'t'),'nonfoodGoods':Q(nonfood_discard,'t')})
flow('green-waste','courts','collection','Prunings','waste',{'wetMass':Q(P['court_green_waste_t_year'],'t')})
flow('organics','collection','digester','Collected organics','waste',{'wetMass':Q(ad_organics,'t'),'totalNitrogen':Q(ad_n-processing_n-sludge_dry*P['sludge_n_fraction_dry'],'t'),'totalPhosphorus':Q(ad_organics*P['organics_p_fraction_wet'],'t')})
flow('dry-recycling','collection','sorter','Dry recyclables','materials',{'materialMass':Q(sort_in,'t')})
flow('repairables','collection','repair','Repairable goods','materials',{'materialMass':Q(reusable_in,'t')})
flow('collection-residual','collection','disposal','Residual waste','waste',{'wetMass':Q(collection_residual,'t')})
flow('recycled-output','sorter','factory','Secondary materials','materials',{'materialMass':Q(sort_product,'t')})
flow('sort-reject','sorter','disposal','Sorting rejects','waste',{'materialMass':Q(sort_reject,'t')})
flow('reused','repair','buildings','Reused goods','materials',{'materialMass':Q(reused,'t')})
flow('repair-reject','repair','disposal','Repair rejects','waste',{'materialMass':Q(repair_reject,'t')})
flow('goods','factory','buildings','Replacement goods','materials',{'materialMass':Q(new_goods,'t')})
flow('secondary-export','factory','buyers','Surplus secondary material','materials',{'materialMass':Q(secondary_export,'t')})
flow('factory-reject','factory','disposal','Processing rejects','waste',{'materialMass':Q(factory_reject,'t')})
flow('digestate','digester','digestate','Digestate','waste',{'wetMass':Q(digestate,'t'),'totalNitrogen':Q(digestate_n,'t'),'totalPhosphorus':Q(ad_p,'t')})
flow('nutrient-return','digestate','farms','Qualified soil amendment','materials',{'wetMass':Q(digestate,'t'),'totalNitrogen':Q(digestate_n,'t'),'totalPhosphorus':Q(ad_p,'t')},'conditional on sanitation, contaminant testing, storage and agronomic approval; not verified fertilizer suitability')

boundary('solar-roof','pv','in',{'radiation':Q(21000*1600/1000,'MWh')},'incident sunlight')
boundary('solar-roof-rejection','pv','out',{'radiantAndThermalEnergy':Q(21000*1600/1000-onsite_pv,'MWh')},'unconverted sunlight and heat')
shore_module_area=P['shore_pv_mwp']*1000/P['pv_kwp_m2']
boundary('solar-shore','shore-pv','in',{'radiation':Q(shore_module_area*1600/1000,'MWh')},'incident sunlight')
boundary('solar-shore-rejection','shore-pv','out',{'radiantAndThermalEnergy':Q(shore_module_area*1600/1000-shore_pv,'MWh')},'unconverted sunlight and heat')
boundary('battery-loss','battery','out',{'heat':Q(battery_loss,'MWh')},'ambient heat')
boundary('network-loss','network','out',{'heat':Q(network_loss,'MWh')},'2% screening electrical loss; no power-flow calculation')
boundary('hp-ambient','hp','in',{'heat':Q(13456.8,'MWh')},'outdoor air in heating modes')
boundary('hp-cooling-rejection','hp','out',{'heat':Q(7700,'MWh')},'outdoor air in cooling mode')
boundary('tank-heat-loss','hot-tanks','out',{'heat':Q(175.2,'MWh')},'ambient heat')
boundary('boiler-loss','boiler','out',{'heat':Q(boiler_stack_loss+heat_surplus,'MWh')},'stack losses and unused heat; no net-positive credit')
boundary('biogas-leak','digester','out',{'methane':Q(methane*P['methane_leak_fraction'],'Nm3'),'methaneMass':Q(leak_mass,'t')},'fugitive methane; explicitly not zero emissions')
boundary('ad-ammonia','digester','out',{'nitrogen':Q(n_loss,'t'),'ammoniaMass':Q(ammonia_loss_mass,'t')},'assumed volatilized nitrogen; mitigation needed')
boundary('boiler-oxygen','boiler','in',{'oxygenMass':Q(4*burn_mass,'t')},'combustion oxygen; inert air not represented')
boundary('boiler-flue','boiler','out',{'carbonDioxide':Q(2.75*burn_mass+co2_mass,'t'),'waterVapor':Q(2.25*burn_mass,'t')},'biogenic combustion products; not a full lifecycle GHG assessment')
boundary('seawater','ro','in',{'water':Q(ro_feed,'m3'),'dissolvedSalt':Q(salt_in,'t')},'marine intake')
boundary('brine','ro','out',{'water':Q(ro_brine,'m3'),'dissolvedSalt':Q(salt_brine,'t')},'marine brine outfall; dispersion and ecological acceptability untested')
boundary('fresh-loss','fresh','out',{'water':Q(fresh_loss,'m3')},'distribution loss')
boundary('house-water-loss','buildings','out',{'water':Q(house_water_loss,'m3')},'non-sewer household water loss')
boundary('ww-evap','ww','out',{'water':Q(ww_evap,'m3')},'evaporation and unreturned process water')
boundary('rain-catch','rain','in',{'water':Q(rain,'m3')},'captured roof rainfall; 20% first-flush/uncollected rainfall is outside this managed-water balance')
boundary('reuse-loss','reuse','out',{'water':Q(reuse_loss,'m3')},'non-potable network loss')
boundary('courts-water-use','courts','out',{'water':Q(courts_water+cleaning_water,'m3')},'evapotranspiration and uncollected cleaning water')
boundary('garden-water-use','garden','out',{'water':Q(garden_water,'m3')},'combined evapotranspiration, purge and crop-bound water; split unresolved')
boundary('farm-rain','farms','in',{'water':Q(farm_rain,'m3')},'rain falling on productive fields')
boundary('farm-et','farms','out',{'water':Q(farm_et,'m3')},'assumed annual evapotranspiration')
boundary('farm-other-drainage','farms','out',{'water':Q(farm_drain,'m3')},'uncaptured drainage/recharge residual; not simulated')
boundary('farm-crop-moisture','farms','out',{'water':Q(farm_crop_water,'m3')},'water incorporated in net harvested foods; not subsequently traced in managed-water loops')
boundary('reservoir-evap','reservoir','out',{'water':Q(reservoir_evap,'m3')},'reservoir evaporation allowance')
boundary('virgin-material','factory','in',{'materialMass':Q(virgin,'t')},'required external virgin industrial feedstocks; extraction impacts excluded')
boundary('additional-nutrients','farms','in',{'availableNitrogenRequired':Q(farm_n_need-n_available,'t'),'availablePhosphorusRequired':Q(farm_p_need-p_available,'t')},'additional nutrient supply requirement from soil, fixation and/or imported amendments; no supplier or sustainable soil budget established','unsecured_design_requirement')

checks=[]
def balance(label,unit,ins,outs,delta=0.0,scope='annual arithmetic balance'):
    residual=sum(ins)-sum(outs)-delta
    checks.append({'check':label,'unit':unit,'input':sum(ins),'output':sum(outs),'delta_stock':delta,
      'residual':residual,'pass':abs(residual)<max(1e-6,abs(sum(ins))*1e-10),'scope':scope})
balance('project operational electricity','MWh',[pv],[demand,battery_loss,network_loss,net])
balance('battery','MWh',[battery_in],[battery_out,battery_loss])
balance('heat pumps','MWh',[7378.4,13456.8,6300],[10500,8935.2,7700])
balance('hot tanks','MWh',[8935.2],[8760,175.2])
balance('biogas boiler useful energy','MWh',[fuel_mwh],[heat_duty,heat_surplus,boiler_stack_loss])
balance('biogas boiler combustion mass','t',[burn_mass,co2_mass,4*burn_mass],[2.75*burn_mass+co2_mass,2.25*burn_mass])
balance('RO water volume','m3',[ro_feed],[ro_product,ro_brine],scope='incompressible screening volume balance; no detailed density model')
balance('RO dissolved salt','t',[salt_in],[salt_product,salt_brine])
balance('freshwater tanks','m3',[ro_product],[potable_house,garden_water,fresh_export,fresh_loss])
balance('household pipe water','m3',[potable_house,reuse_house],[sewer,house_water_loss])
balance('wastewater water fraction','m3',[sewer],[reclaimed,sludge_water,ww_evap])
balance('reuse tanks','m3',[reclaimed,rain],[reuse_city_delivered,reuse_loss,farm_reuse])
balance('farm reservoir','m3',[farm_reuse,farm_capture],[farm_irrigation,reservoir_evap])
balance('farm water','m3',[farm_rain,farm_irrigation],[farm_et,farm_capture,farm_drain,farm_crop_water],scope='prescribed annual hydrologic budget; seasonality and digestate moisture omitted')
balance('food hub harvested-food mass','t',[farm_gross_food_t,garden_t],[food_city_t,food_export_t,food_processing_residue])
balance('city food allocation','t',[food_city_t],[sum(consumed.values()),food_waste],scope='food-use accounting; not human whole-body mass balance')
balance('city food dietary energy','kcal',[food_kcal_city_in],[diet_kcal,food_kcal_city_in*P['city_food_loss_fraction']])
balance('solid-waste collection','t',[P['solid_waste_t_year']],[ad_organics,sort_in,reusable_in,collection_residual])
balance('sorting','t',[sort_in],[sort_product,sort_reject])
balance('repair','t',[reusable_in],[reused,repair_reject])
balance('city nonfood goods stock','t',[new_goods,reused],[nonfood_discard])
balance('manufacturers','t',[sort_product,virgin],[new_goods,secondary_export,factory_reject])
balance('digester wet mass','t',[ad_feed],[digestate,methane_mass,co2_mass,ammonia_loss_mass],scope='aggregate wet mass; elemental carbon, reaction water and feed chemical energy not resolved')
balance('digester nitrogen','t',[ad_n],[digestate_n,n_loss])
balance('digester phosphorus','t',[ad_p],[ad_p],scope='assumed all input P retained in digestate; not measured')
balance('material chain virgin/residual balance','t',[virgin],[secondary_export,city_residual-uncaptured_organics,factory_reject])

sens=[]
for label,solar,load in [('base',1,1),('solar_minus_10_percent',.9,1),('load_plus_25_percent',1,1.25),('combined_low_solar_high_load',.9,1.25)]:
    surplus=pv*solar*(1-P['network_loss_fraction'])-demand*load-battery_loss
    sens.append({'case':label,'net_electricity_mwh_year':surplus,'net_positive':surplus>0,'ten_percent_margin':surplus>=demand*load*.1})
yield_drop_food=.8*farm_food_t+garden_t
sens.append({'case':'farm_yield_minus_20_percent','food_available_t_year':yield_drop_food,
  'city_supply_required_t_year':food_city_t,'shortfall_after_canceling_exports_t_year':max(0,food_city_t-yield_drop_food),
  'interpretation':'fixed crop mix and area; city loss allowance retained; imported food or reduced losses needed'})
sens.append({'case':'garden_energy_25_kwh_kg','extra_electricity_mwh_year':garden_t*(25-P['garden_electricity_kwh_kg']),
 'net_electricity_mwh_year':net-garden_t*(25-P['garden_electricity_kwh_kg']),
 'interpretation':'illustrates climate-controlled greenhouse energy risk; design uses passive seasonal growing'})

sources=[
 {'id':'S1','title':'WHO (2020), Domestic water quantity, service level and health','url':'https://www.who.int/publications/i/item/9789240015241','use':'Domestic service context; 100 L/person/day is a design assumption, not a universal minimum.'},
 {'id':'S2','title':'IEA (2026), Wired for water: How electrification is transforming desalination','url':'https://www.iea.org/commentaries/wired-for-water-how-electrification-is-transforming-desalination','use':'SWRO indicative total electricity 2.5-6 kWh/m3; selected 3.5 is a screening assumption.'},
 {'id':'S3','title':'US EPA, Reusing Water for Agricultural Activities Resources','url':'https://www.epa.gov/waterreuse/reusing-water-agricultural-activities-resources','use':'Treatment and end-use compatibility; no site-specific compliance determination.'},
 {'id':'S4','title':'US EPA, Wasted Food Scale','url':'https://www.epa.gov/sustainable-management-food/wasted-food-scale','use':'Prevention and human food use precede digestion; no incentives to create waste for fuel.'},
 {'id':'S5','title':'US EPA, Basic Information about Anaerobic Digestion','url':'https://www.epa.gov/anaerobic-digestion/basic-information-about-anaerobic-digestion','use':'Co-digestion of food waste and sewage sludge; biogas and digestate outputs. Selected yields are assumptions.'},
 {'id':'S6','title':'Barbosa et al. (2015), Comparison of land, water, and energy requirements of lettuce','url':'https://pmc.ncbi.nlm.nih.gov/articles/PMC4483736/','use':'Study reports about 41 kg/m2/year, 20 L/kg and 25 kWh/kg for controlled hydroponic lettuce. Does NOT validate the chosen passive-garden yield or low electricity budget.'},
 {'id':'S7','title':'FAO, Crop irrigation water requirements','url':'https://www.fao.org/aquastat/en/data-analysis/irrig-water-use/irrig-water-requirement/','use':'Irrigation depends on crop ET, effective rainfall and soil-water changes; annual assumed budget is not daily irrigation verification.'},
 {'id':'S8','title':'NREL 2024 ATB, Commercial Battery Storage','url':'https://atb.nrel.gov/electricity/2024/commercial_battery_storage','use':'85% representative round-trip efficiency.'},
 {'id':'S9','title':'IEA, How a heat pump works','url':'https://www.iea.org/reports/the-future-of-heat-pumps/how-a-heat-pump-works','use':'Heat-transfer accounting; selected COPs remain assumptions.'},
 {'id':'S10','title':'PVWatts, Cautions for interpreting results','url':'https://pvwatts.nlr.gov/docs/en/help_results_interpret.php','use':'Weather, shading and degradation uncertainty. No weather model was run.'},
 {'id':'S11','title':'Microsoft Learn, Use Azure Digital Twins Explorer','url':'https://learn.microsoft.com/en-us/azure/digital-twins/how-to-use-azure-digital-twins-explorer','use':'DTDL v2 model upload and JSON graph import/export.'}]
unknowns=[
 ('climate','Site, solar/weather series, seasonal crop yield, irrigation timing and greenhouse climate control. Crop yields and diet coefficients are screening assumptions.'),
 ('food-nutrition','Full diet design, micronutrients, digestibility, individual needs, preferences and purchased supplements are unresolved. Calorie/protein/fat screen is not complete nutritional adequacy.'),
 ('food-farm-production','Photosynthetic carbon and oxygen, oilseed co-products, field residues, soil-carbon change and field-stage losses are not fully quantified. Food yield starts at the net edible commodity boundary.'),
 ('water-quality','Potable and reclaimed microbial/chemical treatment targets, agricultural reuse suitability, disinfection residuals, antiscalant and membrane replacement, brine dispersion and bypass conditions.'),
 ('water-seasonality','Reservoir routing, drought reliability, crop-specific effective rainfall/ET and seasonal treated-water demand. Digestate moisture and food-bound water are not fully traced in the managed-water loops.'),
 ('nutrients','Whole-farm N/P balances, fixation, soil fertility, salts and contaminant accumulation. Digestate only supplies part of the agronomic nutrient budget.'),
 ('materials','Initial building/platform bills of materials, incorporated material stocks, embodied energy/carbon, service lives, durability and end-of-life recovery. Net-positive lifecycle materials is unproven.'),
 ('materials-grades','70% recycled input is an aggregate procurement target; material-grade compatibility and markets must be secured. Virgin inputs remain.'),
 ('waste','Actual waste composition, capture and reject rates, hazardous/e-waste separation, biosolids/digestate suitability, methane control and residual disposal contracts.'),
 ('physical-structure','12-storey average building massing, hull displacement, stability, mooring, storm exposure, battery/tank loads and service dock handling are not designed.'),
 ('hourly-energy','8760-hour load/weather/storage simulation, peak grid import/export, electrical protection, outage duration and storm reserves.'),
 ('cost-and-SEE','Site-dependent costs, O&M staffing, tariff and export value, agricultural land and water rights, ecological effects, local acceptance and equitable service prices.'),
 ('external-assets','Offsite farms, PV land, utility hub, manufacturers, receiving customers and disposal facility are proposed allocations; none are secured.'),
 ('scope','Operational five-system boundary includes allocated farm/factory/freight electricity. Passenger transport, construction, embodied supply-chain energy and chemical production remain excluded.')]
ledger={'schema_version':'1.0','scenario_id':'floating-city-integrated-12000','period':{'id':PERIOD,'duration_days':D,'start':'design_year_start','end':'design_year_end'},
 'brief':{'population':N,'city_area_ha':6.3,'location':'unspecified'},
 'boundaries':{'city':'6.3 ha floating platforms','project':'city plus dedicated farms, PV, utility hub and allocated processing/freight assets',
  'supporting_land_ha_known':farm_gross_ha+R['shore_pv_ha']+P['shore_utility_hub_land_ha'],
  'land_limit':'Existing regional manufacturing and disposal land are not quantified. Farm buffers include reservoir area; no double counting.',
  'scope':unknowns[-1][1]},
 'goal_definitions':{
  'energy':'annual renewable electricity > all modeled operating electricity plus network/battery losses; 10% design margin',
  'water':'zero imported municipal freshwater, 50 m3/day useful potable export, and irrigation reuse; a service-surplus goal, NOT demonstrated net-positive watershed/ecosystem impact',
  'food':'at least 2400 kcal/person/day planning consumption and edible supply export 10% of city procurement; achieved only with external farms; nutritional completeness unverified',
  'waste':'at least 90% city municipal solid waste routed to verified reuse, recycling and beneficial biological treatment; not zero waste and excludes brine, construction and farm-field residues',
  'materials':'70% recycled feed fraction for modeled operational new goods plus direct repair/reuse; initial/lifecycle material positivity unresolved'},
 'schema_limitations':['Agreed value/unit maps have no time, capacity, evidence or boundary fields: this linked ledger is required.',
  'Boundary records capture natural inputs, losses and unsecured inputs without inventing abstract twins.',
  'Multiple keys can describe overlapping properties of a stream (wetMass, drySolids, nutrients); never sum these as independent mass.',
  'Some units share dimensions but different meanings: food kcal and operational MWh are not combined for the electricity KPI.',
  'Unknown stocks are absent and listed unresolved; absent is not zero. Equal year-end stock is an annual accounting condition, not dynamic proof.'],
 'assumptions':P,'results':R,'asset_records':A,'stock_records':S,'flow_records':F,'boundary_transfers':B,
 'crop_breakdown':{'net_to_food_hub_t_year':farm_food,'gross_to_food_hub_t_year':farm_gross_food,'productive_area_ha':farm_area,
  'yields_note':'Net edible-commodity yields are explicit design assumptions, including processed oil rather than raw oilseed. They require local agronomic evidence.'},
 'conversion_records':{'city_food_consumption_t_year':sum(consumed.values()),'city_food_consumed_kcal_year':diet_kcal,
  'methane_formation_nm3_year':methane,'digester_volatile_solids_t_year':vs,'digester_n_input_t_year':ad_n,'digester_p_input_t_year':ad_p,
  'farm_available_n_budget_t_year':farm_n_need,'farm_available_p_budget_t_year':farm_p_need},
 'validation':checks,'sensitivity':sens,'unresolved':[{'id':k,'status':'unresolved','affected_check':v} for k,v in unknowns],
 'revision':{'reference':'15% city food losses and 10% postharvest losses; 1433 ha gross farm allocation',
  'selected':'10% city food losses and 5% postharvest losses; approximately 1353 ha farms; 21 MWp external PV covers expanded loads',
  'method':'manual balance-driven revision across food, waste, nutrients, land, water and energy; no cost-optimization solver',
  'complexity_control':'shared shore wastewater/digestion/food heat hub; seasonal sunlight-grown vegetables; no LED farms, hydrogen train or duplicated small incinerator'},
 'sources':sources}
models=json.loads((ROOT/'model.json').read_text())
graph={'digitalTwinsFileInfo':{'fileVersion':'1.0.0'},'digitalTwinsModels':[],
 'digitalTwinsGraph':{'digitalTwins':T,'relationships':E}}
save('graph.json',graph);save('twins.json',T);save('relationships.json',E);save('ledger.json',ledger)

# Structural and cross-file checks performed on actual exported values.
ids={t['$dtId'] for t in T}; model_ids={m['@id'] for m in models}
assert len(ids)==len(T)
assert len({(e['$sourceId'],e['$relationshipId']) for e in E})==len(E)
assert all(m['@context']=='dtmi:dtdl:context;2' for m in models)
for t in T:
    assert t['$metadata']['$model'] in model_ids
    assert set(t)=={'$dtId','$metadata','name','system','stock'}
    for k,v in t['stock'].items(): assert set(v)=={'value','unit'} and math.isfinite(v['value']) and isinstance(v['unit'],str)
children=defaultdict(list)
for e in E:
    assert e['$sourceId'] in ids and e['$targetId'] in ids
    if e['$relationshipName']=='contains':
        assert set(e)=={'$relationshipId','$sourceId','$targetId','$relationshipName'}
        children[e['$sourceId']].append(e['$targetId'])
    else:
        assert e['$relationshipName']=='flowsTo' and e['flow']
        assert set(e)=={'$relationshipId','$sourceId','$targetId','$relationshipName','name','system','flow'}
        for v in e['flow'].values(): assert set(v)=={'value','unit'} and math.isfinite(v['value'])
def no_cycle(k,seen):
    assert k not in seen
    for c in children[k]:no_cycle(c,seen|{k})
for k in ids:no_cycle(k,set())
tm={t['$dtId']:t for t in T}; em={e['$relationshipId']:e for e in E}
for s in S:
    assert tm[s['twin_id']]['stock'][s['stock_key']]=={k:s[k] for k in ['value','unit']}
    assert abs(s['end_value']-s['value']-s['delta'])<1e-8
for f in F:
    assert em[f['relationship_id']]['flow'][f['flow_key']]=={k:f[k] for k in ['value','unit']}
    assert f['period_id']==PERIOD
assert all(c['pass'] for c in checks), [c for c in checks if not c['pass']]
assert all(x>=0 for x in [intrinsic_residual,secondary_export,heat_surplus,ww_evap,farm_drain,farm_capture])
assert ro_product/D<P['ro_product_capacity_m3_day'] and sewer/D<1500
assert ad_feed/D<25 and ad_feed/D*25<600
assert 35000+17000+6000+5000==63000
assert 18000+4000<=35000 and 3000<=17000
assert farm_gross_ha-farm_ha>12.5
assert diet_kcal>=P['daily_diet_kcal_person']*N*D
validation={'status':'local_checks_passed','twins':len(T),'relationships':len(E),
 'flow_relationships':sum(e['$relationshipName']=='flowsTo' for e in E),'populated_flow_quantities':len(F),
 'populated_stock_quantities':len(S),'boundary_quantities':len(B),'balance_checks':len(checks),
 'arithmetic_balances':checks,'sensitivity':sens,
 'meaning':'Consistent concept accounting under assumptions; not certification, independent performance evidence or hourly validation.',
 'not_performed':['official Microsoft DTDL parser validation','live Azure import','dynamic energy/water/storage simulation','site engineering','whole-system carbon and nutrient closure','life-cycle net-positive materials assessment','cost optimization']}
save('validation.json',validation)
print(json.dumps({'twins':len(T),'relationships':len(E),'stocks':len(S),'flow_quantities':len(F),'balances':len(checks),
 'annual_demand_GWh':demand/1000,'annual_electricity_surplus_GWh':net/1000,'farm_gross_ha':farm_gross_ha,
 'city_waste_diversion':diversion,'checks_passed':all(c['pass'] for c in checks),'sensitivity':sens},indent=2))
