FLOATING CITY INTEGRATED SYSTEMS

Read Floating_City_Integrated_Blueprint.pdf first.

Azure: upload model.json if absent, then Import Graph using graph.json.
Keep ledger.json for timing, capacity, boundary, evidence and unresolved quantities.

Reproduce model: python3 calculations.py (standard Python library).
Rebuild PDF: python3 build_report.py (requires reportlab; fonts are bundled).

This package is a conditional concept design. Read validation.json and the report limitations.
No live Azure import, hourly simulation or marine structural check was performed.
