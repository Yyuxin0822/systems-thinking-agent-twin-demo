#!/usr/bin/env python3
from pathlib import Path
import json
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
FONT_DIR=Path(__file__).resolve().parent/'fonts'
pdfmetrics.registerFont(TTFont('DVS',str(FONT_DIR/'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DVS-Bold',str(FONT_DIR/'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFontFamily('DVS',normal='DVS',bold='DVS-Bold',italic='DVS',boldItalic='DVS-Bold')
ROOT=Path(__file__).resolve().parent
L=json.loads((ROOT/'ledger.json').read_text()); R=L['results']; P=L['assumptions']; V=json.loads((ROOT/'validation.json').read_text())
OUT=ROOT/'Floating_City_Integrated_Blueprint.pdf'
W,H=A4; margin=43; width=W-2*margin
ink=colors.HexColor('#173D36'); teal=colors.HexColor('#286E60'); pale=colors.HexColor('#EAF3ED'); gray=colors.HexColor('#53645E')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleX',fontName='Helvetica-Bold',fontSize=28,leading=32,textColor=ink,spaceAfter=14))
styles.add(ParagraphStyle(name='HeadX',fontName='Helvetica-Bold',fontSize=19,leading=23,textColor=ink,spaceAfter=12))
styles.add(ParagraphStyle(name='SubX',fontName='Helvetica-Bold',fontSize=11,leading=15,textColor=teal,spaceBefore=10,spaceAfter=5))
styles.add(ParagraphStyle(name='BodyX',fontName='Helvetica',fontSize=9.8,leading=13.8,textColor=ink,spaceAfter=9))
styles.add(ParagraphStyle(name='SmallX',fontName='Helvetica',fontSize=8.3,leading=11.2,textColor=gray,spaceAfter=6))
styles.add(ParagraphStyle(name='CellX',fontName='Helvetica',fontSize=8.7,leading=11.4,textColor=ink))
styles.add(ParagraphStyle(name='CellH',fontName='Helvetica-Bold',fontSize=8.7,leading=11.4,textColor=colors.white))
styles.add(ParagraphStyle(name='KpiX',fontName='Helvetica-Bold',fontSize=18,leading=22,textColor=ink,spaceAfter=4))
for st in styles.byName.values():
    if getattr(st,'fontName',None)=='Helvetica':st.fontName='DVS'
    elif getattr(st,'fontName',None)=='Helvetica-Bold':st.fontName='DVS-Bold'
story=[]
def p(text,style='BodyX'): story.append(Paragraph(text,styles[style]))
def sub(t):p(t,'SubX')
def page(n,title):
    if story:story.append(PageBreak())
    p(f'FLOATING CITY / INTEGRATED SYSTEMS / {n:02d}','SmallX');p(title,'HeadX')
def table(head,rows,widths=None):
    data=[[Paragraph(escape(str(v)),styles['CellH']) for v in head]]
    for row in rows:data.append([Paragraph(escape(str(v)),styles['CellX']) for v in row])
    t=Table(data,colWidths=widths or [width/len(head)]*len(head),repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),ink),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,pale]),
      ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),
      ('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.5,ink)]))
    story.append(t);story.append(Spacer(1,10))
def fmt(x,d=0):return f'{x:,.{d}f}'

page(1,'A city and its supporting region')
p('6.3 hectares | 12,000 people | location unspecified','SubX')
p('The selected concept connects a compact floating city to dedicated solar, farms and shared treatment assets on shore. It produces modeled annual energy, food and freshwater-service surpluses. Waste and materials are governed by recovery targets; full lifecycle material positivity is not established.')
table(['System','Base-case result','Meaning'],[
 ['Energy',f"+{R['net_electricity_export_mwh_year']/1000:.2f} GWh/year",'13.7% surplus over operating electricity after network and battery losses.'],
 ['Water','50 m3/day potable export','No imported municipal freshwater in the assumed annual budget; environmental positivity unproven.'],
 ['Food',f"{R['food_exports_t_year']:.0f} t/year edible surplus",'10% of city procurement, dependent on regional farms.'],
 ['Waste',f"{R['waste_diversion_fraction']:.1%} city MSW diversion",'Reuse, recycling and beneficial biological treatment; not zero waste.'],
 ['Materials','70% recycled-content target','Applies to modeled operational new goods. Initial construction and lifecycle impacts remain unresolved.']],[65,140,width-205])
sub('Two explicit boundaries')
p(f"The city remains 6.3 ha. The expanded project additionally requires about <b>{R['farm_gross_ha']:,.0f} ha of farmland</b>, <b>{R['shore_pv_ha']:.1f} ha of solar land</b>, and a <b>2 ha shared utility hub</b>. Known supporting land totals about {L['boundaries']['supporting_land_ha_known']:,.0f} ha; existing manufacturers and disposal facilities add unquantified land. These proposed assets and customers have not been secured.")
p('The operating boundary includes allocated farm, processing, manufacturing and cargo electricity. It excludes construction, upstream embodied energy, chemical manufacturing and passenger transport. Consequently, the results do not establish an autonomous or lifecycle net-positive city.')
sub('Design logic')
p('Reduce demand and food losses first. Share shore-side treatment and processing equipment. Reuse water and qualified nutrients where there is a real receiving demand. Keep residuals, losses and external inputs visible. Retain grid support and independent delivery routes instead of assuming annual surplus guarantees continuous service.')
p('All figures are concept assumptions or calculations for a synthetic 365-day year. The location, weather, soil, diet, infrastructure costs and engineering layouts are not yet established.','SmallX')

page(2,'Energy: cover all five operating systems')
table(['Electricity item','GWh/year'],[
 ['4.2 MWp roof/canopy PV',f"{P['rooftop_pv_mwp']*P['pv_yield_kwh_kwp_year']/1000:.3f}"],
 ['21 MWp shore PV',f"{P['shore_pv_mwp']*P['pv_yield_kwh_kwp_year']/1000:.3f}"],
 ['Total PV production',f"{R['pv_generation_mwh_year']/1000:.3f}"],
 ['Total operating demand',f"{R['electricity_demand_mwh_year']/1000:.3f}"],
 ['Battery and network losses',f"{(R['battery_loss_mwh_year']+R['network_loss_mwh_year'])/1000:.3f}"],
 ['Annual net electricity export',f"{R['net_electricity_export_mwh_year']/1000:.3f}"]],[width-120,120])
p('PV production assumes 1,300 kWh/kWp/year at plant AC output. It is not a weather-model result. The 21 MWp external array replaces the prior energy-only design\'s 18 MWp array. Detailed water and other system loads replace the previous generic municipal allowance; that allowance is not counted twice.')
table(['Asset or service','Selected provision'],[
 ['Buildings and thermal services','420,000 m2 floor area; 14.70 GWh direct electricity, 7.38 GWh heat-pump electricity, and 0.40 GWh auxiliaries. Heating/cooling loads are assumptions.'],
 ['Battery','5 MW / 20 MWh; initial stock 10 MWh; operating band 2-18 MWh. 2.190 GWh charge, 1.862 GWh discharge and 0.329 GWh loss annually.'],
 ['Hot-water buffers','250 m3 water; 11.61 MWh thermal stock at 60 C relative to 20 C. Usable heat across 45-65 C is 5.81 MWh.'],
 ['New operating loads','Water services 1.68 GWh; farming and food handling about 1.25 GWh; materials manufacturing 1.75 GWh; waste/repair, cargo and other loads are explicitly included.'],
 ['Biogas boiler',f"{R['biogas_heat_mwh_year']/1000:.2f} GWh/year useful heat potential; 0.30 GWh to digestion and 0.60 GWh to adjacent food processing. Unused heat receives no surplus credit."]],[130,width-130])
p('The 85% battery round-trip efficiency follows a generic technology baseline [S8]. Heat-pump environmental heat is accounted separately [S9]; it is not added to PV electricity. Biogas supplies local process heat, avoiding an additional generator and a subsea heat-distribution network.')
p('Grid imports and exports occur at different times. Only their annual net difference is calculated. Hourly dispatch, protection, peak sizing, critical-load adequacy and extended storm outages remain untested. PV weather and shading uncertainty must be evaluated before procurement [S10].','SmallX')

page(3,'Water: separate potable and reuse loops')
table(['Daily water flow','m3/day'],[
 ['Household potable supply',840],['Household non-potable reuse',360],
 ['RO freshwater production',fmt(R['potable_product_m3_day'],1)],
 ['Useful potable export to shore utility',50],['Wastewater influent',1080],
 ['Treated reclaimed water',fmt(R['reclaimed_m3_day'],1)],
 ['Rainwater captured, annual-average equivalent',fmt(R['rain_captured_m3_year']/365,1)],
 ['Reclaimed/rainwater export to farm reservoir',fmt(R['farm_reuse_m3_day'],1)]],[width-125,125])
p('The 100 L/person/day household allowance comprises 70 L potable and 30 L non-potable service. WHO provides service-level context, not a universal design allowance [S1]. Potable water also supplies about 3.3 m3/day to the food garden. Reuse supplies 43 m3/day for courts and cleaning. Both networks include a 3% distribution-loss allowance.')
sub('Assets and operating stocks')
p('Provide a 1,200 m3/day duty RO plant with standby treatment capacity; a 1,500 m3/day duty wastewater/reuse plant; 3,000 m3 potable storage; 1,000 m3 reuse storage; and a 500 m3 rain cistern. Initial water stocks are 1,800, 500 and 200 m3 respectively. The city holds only part of the potable/reuse storage; heavier treatment and reserves sit on shore.')
p(f"At 45% RO recovery, seawater intake is <b>{R['ro_seawater_m3_day']:,.0f} m3/day</b> and brine discharge is <b>{R['ro_brine_m3_day']:,.0f} m3/day</b>, at approximately <b>{R['ro_brine_salt_kg_m3']:.1f} kg/m3 salt</b>. The assumed 3.5 kWh/m3 product-water electricity lies within the IEA's broad SWRO range [S2]. These figures do not demonstrate outfall acceptability.")
sub('Farm water coupling')
p(f"The farm irrigation budget is {R['farm_irrigation_m3_year']/1e6:.2f} million m3/year. Reuse supplies {R['farm_reuse_m3_day']*365/R['farm_irrigation_m3_year']:.1%}; captured runoff supplies the remainder plus reservoir evaporation. A 500,000 m3 reservoir holds an initial 300,000 m3. Its approximate 12.5 ha water area is included in farm buffers, not added twice.")
p('Food-crop reuse requires treatment matched to the crop and exposure route [S3]. The onboard garden uses potable-quality makeup. Reclaimed water cannot simply be sent to edible surfaces. Daily rainfall, storage routing and drought reliability still require testing under FAO crop-water methods [S7]. Exported freshwater is a service surplus; no net-positive ecological or watershed claim is made.','SmallX')

page(4,'Food: regional staples, seasonal city produce')
table(['Commodity','Consumed, t/year','Productive area, ha'],[
 [k.title(),fmt(P['consumed_food_t_year'][k]),fmt(R['farm_area_by_crop_ha'][k],1)] for k in ['grain','pulses','oil','roots','produce']],[150,150,width-300])
p(f"The planning basket provides approximately <b>{R['food_consumed_kcal_person_day']:,.0f} kcal/person/day</b>, {R['food_protein_g_person_day']:.0f} g protein and {R['food_fat_g_person_day']:.0f} g fat. These population-average screens do not establish a complete diet: micronutrients, digestibility, different ages, preferences and supplements remain unresolved.")
table(['Food account','t/year'],[
 ['Gross farm food delivered to processing',fmt(R['farm_gross_food_t_year'],1)],
 ['Onboard garden harvest',fmt(R['garden_food_t_year'],1)],
 ['Postharvest processing residues',fmt(R['food_processing_residue_t_year'],1)],
 ['City food procurement',fmt(R['food_city_supply_t_year'],1)],
 ['Food consumed in the city',fmt(R['food_consumed_t_year'],1)],
 ['City food residues',fmt(R['food_waste_t_year'],1)],
 ['Edible exports',fmt(R['food_exports_t_year'],1)]],[width-125,125])
p(f"Allocate {R['farm_productive_ha']:,.0f} ha of productive fields and {R['farm_gross_ha']:,.0f} ha gross land including 20% for rotation, ecological buffers and water infrastructure. Assumed net yields are 6 t/ha grain, 3 t/ha pulses, 0.8 t/ha edible oil, and 25 t/ha roots and produce. Oil yield means processed oil, not oilseed mass. Crop residues, press cake and full farm carbon/nutrient cycles require further accounting.")
p('Use 4,000 m2 of roofs for seasonal sunlit beds and passive shelters. At an assumed 15 kg/m2/year, the garden produces 60 t/year, approximately 1.1% of city food supply by mass and about 0.1% of city food calories. It is an amenity and fresh-produce asset, not the staple-food supply.')
p('A controlled lettuce study reported approximately 20 L/kg water and 25 kWh/kg energy [S6]. Its results do not validate the selected low-energy garden. The model uses 1.5 kWh/kg for passive seasonal production and separately tests 25 kWh/kg. LED farms are excluded from the selected concept.')

page(5,'Waste and nutrients: recovery with real outlets')
table(['City municipal solid-waste route','t/year'],[
 ['Total generated after prevention',fmt(R['waste_generated_t_year'],1)],
 ['Collected organics to digestion',fmt(R['ad_organics_t_year'],1)],
 ['Sorted secondary material',fmt(R['recycled_output_t_year'],1)],
 ['Repaired/reused goods',fmt(R['reused_t_year'],1)],
 ['City residual disposal',fmt(R['city_residual_t_year'],1)]],[width-125,125])
p(f"City MSW diversion is <b>{R['waste_diversion_fraction']:.1%}</b>. This requires 98% organics and dry-recyclables capture, 97% sorting yield and 95% repair yield. It is a performance target, not an observed rate. It excludes brine, construction waste and unquantified farm-field residues. Manufacturing adds another {R['factory_reject_t_year']:.1f} t/year of rejects outside the city MSW denominator.")
sub('Share one shore-side biological treatment hub')
p(f"Co-digest {R['ad_organics_t_year']:.1f} t/year city organics, {R['food_processing_residue_t_year']:.1f} t/year processing residues and wastewater sludge. Total wet feed is {R['ad_feed_t_year']:,.0f} t/year, about {R['ad_feed_t_year']/365:.1f} t/day. Two 300 m3 digesters provide nominal hydraulic capacity, subject to organic loading, sanitation and operator design. EPA describes this feedstock combination and its biogas/digestate outputs [S5].")
p(f"Assumed methane yield produces about {R['methane_nm3_year']:,.0f} Nm3/year. A 1% leakage allowance is explicitly recorded ({R['methane_leak_t_year']:.2f} t CH4/year). Recovered useful heat supplies 0.90 GWh/year of identified local demand; approximately {R['biogas_heat_surplus_mwh_year']/1000:.2f} GWh/year remains unused. Feedstock chemistry and methane capture require verification.")
sub('Qualified nutrient return, not a closed fertilizer loop')
p(f"Annual digestate is about {R['digestate_t_year']:,.0f} wet tonnes, containing {R['digestate_n_t_year']:.1f} t total N and {R['digestate_p_t_year']:.1f} t total P. First-year availability assumptions give {R['first_year_available_n_t']:.1f} t N and {R['first_year_available_p_t']:.1f} t P, only {R['first_year_available_n_t']/R['farm_n_requirement_t_year']:.1%} and {R['first_year_available_p_t']/R['farm_p_requirement_t_year']:.1%} of the screening farm nutrient budgets. Additional sources remain necessary.")
p('Provide covered 2,500 m3 digestate storage, with an initial 1,000 t stock. Land application is conditional on sanitation, contaminants, salinity and agronomic suitability. Prefer food prevention, redistribution and edible use before digestion [S4]. The selected 10% city and 5% postharvest loss targets reduce farm area from an earlier 1,433 ha screen to 1,353 ha.')

page(6,'Materials, space and operating choices')
table(['Operational material flow','t/year'],[
 ['Repaired goods returned to the city',fmt(R['reused_t_year'],1)],
 ['New goods delivered to the city',fmt(R['new_goods_t_year'],1)],
 ['Required virgin manufacturing feedstock',fmt(R['virgin_feedstock_t_year'],1)],
 ['Surplus secondary material exported',fmt(R['secondary_export_t_year'],1)],
 ['Manufacturing process rejects',fmt(R['factory_reject_t_year'],1)]],[width-125,125])
p('The manufacturing screen targets 70% recycled input for operational new goods and a 95% process yield. It assumes recycled and virgin streams can form an appropriate product mix; grade compatibility is unverified. A 1,000 kWh/t feedstock-processing electricity allowance is included. Additional upstream extraction and chemical-production impacts are excluded.')
p('Use standard replaceable components, reversible connections, material passports, repair access and supplier take-back arrangements. Grade marine-exposed components for durability; a higher recycled-content target cannot justify shortened service life. Initial hull/building material quantities and lifecycle impacts remain unresolved, so a net-positive materials claim would be premature.')
table(['City platform allocation','m2'],[['Building footprint',35000],['Public space and circulation',17000],['Planted courts',6000],['Municipal and energy compound',5000],['Total',63000]],[width-125,125])
p('Roof PV uses 18,000 m2 and food growing 4,000 m2 of the building roof allocation. Another 3,000 m2 of PV sits over circulation. These overlays are not added to platform land. Heavy RO, wastewater and digestion infrastructure is on shore. The 420,000 m2 floor-area assumption requires an average 12 storeys over the building footprint; hull stability, buoyancy, structure and fire access remain unverified.')
sub('Keep the operating system manageable')
p('Combine water treatment, digestion and food-process heat at a shared shore hub. Maintain separate potable and reuse pipes, metered electrical feeders and sealed waste containers. Store the bulk of water, food and digestate on shore. Use the floating city for essential day storage, repair access, compact growing and critical-load batteries.')
p('Economic validation still needs parcel and connection costs, marine logistics, operator staffing, replacement cycles, tariffs and signed export outlets. Social design must protect affordable essential water/power and equitable access. Environmental review must address brine, nutrient runoff, methane, shore habitat and material replacement. No cost optimum or net environmental benefit is asserted.','SmallX')

page(7,'Checks, sensitivities and the next design gate')
table(['Stress case','Calculated effect'],[
 ['Solar yield 10% lower',f"+{L['sensitivity'][1]['net_electricity_mwh_year']/1000:.2f} GWh/year electricity; below the 10% design margin."],
 ['Operating electricity 25% higher',f"{L['sensitivity'][2]['net_electricity_mwh_year']/1000:.2f} GWh/year; annual net-positive target fails."],
 ['Farm yields 20% lower',f"{L['sensitivity'][4]['shortfall_after_canceling_exports_t_year']:.0f} t/year food shortfall even after canceling exports."],
 ['Garden uses 25 kWh/kg',f"Adds 1.41 GWh/year; electricity surplus falls to {L['sensitivity'][5]['net_electricity_mwh_year']/1000:.2f} GWh/year."],
 ['Drought or multi-day grid outage','No dynamic reliability result. Annual budgets cannot establish continuity.']],[150,width-150])
p(f"<b>{V['balance_checks']} local arithmetic checks passed.</b> They cover project electricity, battery and heat conversion, water volumes, RO salt, food allocation, city waste routes, manufacturing, and digester wet mass/N/P. Stocks have explicit starting values and equal-year-end constraints. These are accounting checks, not independent validation of assumed performance.")
p('Whole-farm elemental carbon and nutrient closure, embodied materials, food nutritional completeness, biosolids safety, seasonal reservoir sufficiency and marine feasibility remain incomplete. Several loss terms are calculated residuals. A zero residual is not evidence that a facility can achieve the assumed capacity or yield.')
sub('Next design gate')
p('Choose a climate and shore setting; confirm farm/solar parcels and receiving users; obtain hourly weather and load data; route daily water and food storage; verify crop yields and water quality; price the shared utility hub and logistics; and establish the floating platform mass and stability budget. Resize generation and storage after these inputs are available.')
sub('Azure Digital Twins deliverables')
p(f"The package contains the unchanged agreed <b>model.json</b> and a populated <b>graph.json</b> with {V['twins']} physical-asset twins and {V['relationships']} relationships. There are {V['populated_stock_quantities']} populated stock quantities and {V['populated_flow_quantities']} flow quantities. The ledger preserves time bases, capacities, assumptions, boundaries, missing quantities and sources.")
p('Upload model.json only if the exact interfaces are absent, then use Twin Graph &gt; Import Graph &gt; graph.json &gt; review &gt; Save [S11]. Models use DTDL language context 2; model version ;3 is not DTDL v3. Existing twins are not deleted. Official DTDL-parser validation and live Azure import were not performed.')
p("Query: <font face='Courier' size='8'>SELECT * FROM digitaltwins T WHERE STARTSWITH(T.$dtId, 'fc63x-')</font>",'SmallX')
p('Reproduce the data with python3 calculations.py. Then run python3 build_report.py to refresh this PDF. Keep ledger.json with the graph: the agreed value/unit maps cannot themselves store time, evidence or boundary status.','SmallX')

page(8,'Evidence and assumption register')
p('Sources establish methods, general technology behavior and cautionary benchmarks. They do not validate the selected location-free scenario. All numerical design inputs are retained in scenario.json; unresolved quantities and exclusions are in ledger.json.')
for s in L['sources']:
    p(f"<b>[{s['id']}] {escape(s['title'])}</b>",'SmallX')
    p(escape(s['use']),'SmallX')
    p(f"<link href='{escape(s['url'])}' color='#286E60'>{escape(s['url'])}</link>",'SmallX')
    story.append(Spacer(1,3))
p('Prepared 1 November 2026. No named floating-city project was used as the design template.','SmallX')

def footer(c,doc):
    c.setStrokeColor(colors.HexColor('#BED1C5'));c.line(margin,35,W-margin,35)
    c.setFont('DVS',7.5);c.setFillColor(gray)
    c.drawString(margin,23,'FLOATING CITY | CONCEPT DESIGN | 01 NOV 2026')
    c.drawRightString(W-margin,23,str(doc.page))
doc=SimpleDocTemplate(str(OUT),pagesize=A4,rightMargin=margin,leftMargin=margin,topMargin=38,bottomMargin=48,
 title='Floating City Integrated Systems Blueprint',author='Environmental Metabolism Modeling',pageCompression=1)
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(str(OUT))
