"""Illustrative detention design; not a site-specific or regulatory model.
Run: python3 calculations.py. Requires numpy. Writes results and timeseries JSON.
"""
from pathlib import Path
import json
import numpy as np

ROOT = Path(__file__).resolve().parent
G = 9.81
DESIGN = dict(bottom_length_m=70., bottom_width_m=20., side_slope_HV=4.,
              operational_depth_m=2.5, rim_depth_m=3., net_storage_factor=0.9,
              orifice_width_m=0.20, orifice_height_m=0.20, discharge_coefficient=0.62,
              upper_weir_width_m=0.43, upper_weir_crest_m=1.1,
              emergency_weir_width_m=3., emergency_weir_crest_m=2.5,
              weir_coefficient_SI=1.7)

def storage(h):
    length=DESIGN['bottom_length_m'];width=DESIGN['bottom_width_m'];z=DESIGN['side_slope_HV']
    return DESIGN['net_storage_factor'] * (length*width*h+z*(length+width)*h*h+4*z*z*h*h*h/3)

def rating(h, width=None, upper=None, blockage=0.):
    width = DESIGN['orifice_width_m'] if width is None else width
    upper = DESIGN['upper_weir_width_m'] if upper is None else upper
    h=np.asarray(h)
    # Integrates velocity across vertical rectangular opening; valid when partly wet.
    primary=(1-blockage)*2/3*0.62*width*np.sqrt(2*G)*(np.maximum(h,0)**1.5-np.maximum(h-0.2,0)**1.5)
    primary+=(1-blockage)*1.7*upper*np.maximum(h-DESIGN['upper_weir_crest_m'],0)**1.5
    spill=1.7*DESIGN['emergency_weir_width_m']*np.maximum(h-DESIGN['emergency_weir_crest_m'],0)**1.5
    return primary,spill

def cumulative_runoff(p,cn):
    s=25400/cn-254
    return np.maximum(p-0.2*s,0)**2/(np.maximum(p-0.2*s,0)+s)

def uh_kernel(tc_min,dt):
    # Normalized triangular approximation, not the full NRCS curvilinear UH.
    tp=0.6*tc_min*60+dt/2
    tb=2.67*tp
    t=(np.arange(int(np.ceil(tb/dt)))+0.5)*dt
    y=np.where(t<tp,t/tp,np.maximum((tb-t)/(tb-tp),0))
    return y/y.sum()

def hydrology(depth_mm,dt=60,center=12.):
    n=int(96*3600/dt)
    th=(np.arange(n)+0.5)*dt/3600
    # Explicitly hypothetical 24-h distribution: 40% central hour, 30% adjacent
    # five hours, 30% other eighteen hours. Center can vary from hour 3 to 21.
    intensity=np.where(th<24,0.30/18,0.)
    intensity=np.where(np.abs(th-center)<3,0.30/5,intensity)
    intensity=np.where(np.abs(th-center)<0.5,0.40,intensity)
    rain=depth_mm*intensity*dt/3600
    assert abs(rain.sum()-depth_mm)<1e-7
    cumulative=np.cumsum(rain)
    increments={}
    for name,cn,area,tc in [('pre',71,100000,30),('hard',98,60000,15),('land',74,35000,15)]:
        raw=np.diff(np.r_[0,cumulative_runoff(cumulative,cn)])*area/1000
        increments[name]=np.convolve(raw,uh_kernel(tc,dt))[:n]
    increments['direct']=rain*5000/1000
    increments['rain']=rain
    increments['inflow']=increments['hard']+increments['land']+increments['direct']
    return th,increments

def route(depth_mm,dt=60,width=None,upper=None,blockage=0.,initial_depth=0.,center=12.):
    th,v=hydrology(depth_mm,dt,center)
    hg=np.linspace(0,4,40001)
    sg=storage(hg)
    qg,eg=rating(hg,width,upper,blockage)
    # Implicit finite-volume reservoir routing: Snew+dt*Qnew=Sold+Vin.
    fg=sg+dt*(qg+eg)
    sn=np.zeros(len(th)+1);sn[0]=storage(initial_depth)
    hn=np.zeros(len(th));qn=hn.copy();en=hn.copy()
    for i,vin in enumerate(v['inflow']):
        h=np.interp(sn[i]+vin,fg,hg)
        if h>=hg[-1]: raise ValueError('Routing table exceeded')
        hn[i]=h
        qn[i]=np.interp(h,hg,qg);en[i]=np.interp(h,hg,eg)
        sn[i+1]=np.interp(h,hg,sg)
    j=int(np.argmax(sn[1:]))
    endrain=int(24*3600/dt)
    dry=np.flatnonzero((np.arange(len(hn))>=endrain)&(hn<=0.01))
    peakindex=j+1
    r=dict(depth_mm=depth_mm,dt_s=dt,storm_center_h=center,
      pre_peak_m3s=float(v['pre'].max()/dt),pre_volume_m3=float(v['pre'].sum()),
      inflow_peak_m3s=float(v['inflow'].max()/dt),inflow_volume_m3=float(v['inflow'].sum()),
      hard_volume_m3=float(v['hard'].sum()),land_volume_m3=float(v['land'].sum()),
      direct_volume_m3=float(v['direct'].sum()),
      out_peak_m3s=float((qn+en).max()),primary_peak_m3s=float(qn.max()),
      out_volume_m3=float((qn+en).sum()*dt),primary_volume_m3=float(qn.sum()*dt),
      spill_volume_m3=float(en.sum()*dt),spill_peak_m3s=float(en.max()),
      storage_peak_m3=float(sn.max()),depth_peak_m=float(hn.max()),
      peak_time_h=float(peakindex*dt/3600),initial_storage_m3=float(sn[0]),
      final_storage_m3=float(sn[-1]),final_depth_m=float(hn[-1]),
      peak_cumulative_in_m3=float(v['inflow'][:peakindex].sum()),
      peak_cumulative_out_m3=float((qn[:peakindex]+en[:peakindex]).sum()*dt),
      mass_residual_m3=float(sn[0]+v['inflow'].sum()-(qn+en).sum()*dt-sn[-1]),
      hours_after_rain_to_10mm=float((dry[0]+1)*dt/3600-24) if len(dry) else None,
      peak_limit_pass=bool((qn+en).max()<=v['pre'].max()/dt),
      operational_storage_pass=bool(hn.max()<DESIGN['operational_depth_m']),
      rim_freeboard_m=float(DESIGN['rim_depth_m']-hn.max()))
    data=dict(time_end_h=((np.arange(len(th))+1)*dt/3600).tolist(),
       rain_mm=v['rain'].tolist(),pre_q_m3s=(v['pre']/dt).tolist(),
       hard_q_m3s=(v['hard']/dt).tolist(),land_q_m3s=(v['land']/dt).tolist(),
       direct_q_m3s=(v['direct']/dt).tolist(),in_q_m3s=(v['inflow']/dt).tolist(),
       out_q_m3s=(qn+en).tolist(),primary_q_m3s=qn.tolist(),spill_q_m3s=en.tolist(),
       depth_m=hn.tolist(),storage_m3=sn[1:].tolist())
    return r,data

def main():
    results={};series={}
    for label,depth in [('2y',75),('10y',110),('100y',160)]:
        results[label],series[label]=route(depth)
    candidates=[]
    for u in [0.,0.3,0.4,0.43]:
        rs=[route(d,upper=u)[0] for d in [75,110,160]]
        candidates.append(dict(low_orifice_width_m=.2,upper_weir_width_m=u,depths_m=[r['depth_peak_m'] for r in rs],
             out_peaks_m3s=[r['out_peak_m3s'] for r in rs],
             all_pass=all(r['peak_limit_pass'] and r['operational_storage_pass'] for r in rs)))
    sensitivity={};sensitivity_series={}
    for name,args in [('rain_plus20',dict(depth_mm=192)),('half_blocked',dict(depth_mm=160,blockage=.5)),
                      ('initial_0p5m',dict(depth_mm=160,initial_depth=.5)),
                      ('front_loaded',dict(depth_mm=160,center=3.)),
                      ('back_loaded',dict(depth_mm=160,center=21.))]:
        sensitivity[name],sensitivity_series[name]=route(**args)
    refinement={label:route(depth,dt=30)[0] for label,depth in [('2y',75),('10y',110),('100y',160)]}
    output=dict(design=DESIGN,base=results,candidates=candidates,sensitivity=sensitivity,refinement=refinement)
    (ROOT/'results.json').write_text(json.dumps(output,indent=2))
    (ROOT/'timeseries.json').write_text(json.dumps(series,separators=(',',':')))
    (ROOT/'sensitivity_timeseries.json').write_text(json.dumps(sensitivity_series,separators=(',',':')))
    print(json.dumps(output,indent=2))
if __name__=='__main__':main()
