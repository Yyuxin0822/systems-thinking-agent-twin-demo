"""Create the populated Azure export, ledger, figures, and concise design PDF."""
from pathlib import Path
import json, math, shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.units import inch
from calculations import storage, DESIGN

P=Path(__file__).resolve().parent
R=json.loads((P/'results.json').read_text()); TS=json.loads((P/'timeseries.json').read_text())
SENS=json.loads((P/'sensitivity_timeseries.json').read_text())
MODELS=json.loads((P/'model.json').read_text())
SOURCES=[
 ('USACE, HEC-HMS Technical Reference Manual: CN Tables', 'https://www.hec.usace.army.mil/confluence/hmsdocs/hmstrm/cn-tables'),
 ('USACE, SCS Curve Number Loss Model', 'https://www.hec.usace.army.mil/confluence/hmsdocs/hmstrm/canopy-surface-infiltration-and-runoff-volume/infiltration/scs-curve-number-loss-model'),
 ('USACE, SCS Unit Hydrograph Model', 'https://www.hec.usace.army.mil/confluence/hmsdocs/hmstrm/transform/scs-unit-hydrograph-model'),
 ('FHWA (2024), HEC-22, Urban Drainage Design, 4th ed., Chapter 10', 'https://www.fhwa.dot.gov/engineering/hydraulics/pubs/hif24006.pdf'),
 ('Microsoft Learn, Use Azure Digital Twins Explorer: Import/export graph', 'https://learn.microsoft.com/en-us/azure/digital-twins/how-to-use-azure-digital-twins-explorer#importexport-graph')]

def dump(name,obj):
 (P/name).write_text(json.dumps(obj,indent=2,allow_nan=False))

assets=[('hard','Roofs & paving','InputTwin','inside','6 ha connected impervious asset assembly; assumed CN 98'),
 ('land','Landscape','InputTwin','inside','3.5 ha residential landscape; assumed CN 74'),
 ('pond','Pond','ProcessTwin','inside','Excavated vegetated basin with sediment bay; 0.5 ha footprint'),
 ('outlet','Outlet','ProcessTwin','inside','Two-level outlet chamber, screen, and discharge pipe'),
 ('spill','Spillway','ProcessTwin','inside','3 m emergency overflow crest at 2.5 m above basin bottom'),
 ('reach','Receiving swale','OutputTwin','outside','Proposed receiving swale/reach; alignment and capacity unresolved'),
 ('pre','Existing meadow','InputTwin','counterfactual baseline','Assumed 10 ha existing meadow; replaced by proposed development, CN 71')]
twins=[{'$dtId':'dp-'+a,'$metadata':{'$model':f'dtmi:environmental:{m};3'},'name':n,'system':'stormwater','stock':{}} for a,n,m,b,d in assets]
byid={t['$dtId']:t for t in twins}
rels=[]
for id,src,dst,name in [('hardIn','hard','pond','Hardscape runoff'),('landIn','land','pond','Landscape runoff'),
 ('controlled','pond','outlet','Controlled release'),('discharge','outlet','reach','Discharge'),
 ('overflow','pond','spill','Emergency overflow'),('spillDischarge','spill','reach','Spillway discharge'),
 ('baseline','pre','reach','Pre-development runoff')]:
 rels.append({'$relationshipId':'dp-'+id,'$sourceId':'dp-'+src,'$targetId':'dp-'+dst,
 '$relationshipName':'flowsTo','name':name,'system':'stormwater','flow':{}})
byrel={t['$relationshipId']:t for t in rels}
ledger=dict(title='Detention pond: illustrative metabolism model',date='2026-11-01',status='concept only; no site-specific compliance claim',
 boundary={'design_site_m2':100000,'pond_footprint_included_in_site_m2':5000,'accounting_window_h':[0,96],
 'storm_window_h':[0,24],'reference_clock':'hours since start of each independent hypothetical storm',
 'rainfall':'External boundary flux; no abstract atmosphere or rainfall twin is created.',
 'baseline':'dp-pre is an alternative land-cover scenario, not an additional 10 ha contributing area.'},
 assets=[dict(twin_id='dp-'+a,name=n,model=f'dtmi:environmental:{m};3',boundary=b,description=d) for a,n,m,b,d in assets],
 assumptions={'rainfall_depths_mm':{'2y':75,'10y':110,'100y':160},'rainfall_frequency_status':'Assumed labels, NOT location-derived frequency estimates',
 'hyetograph':'40% in central hour; 30% in adjacent five hours; 30% in remaining 18 hours; peak hour centered at hour 12',
 'soil_group':'C assumed','antecedent_condition':'average','pre_cover':'meadow assumed','curve_numbers':{'pre':71,'hard':98,'land':74},
 'concentration_time_min':{'pre':30,'post':15},'initial_pond_water_m3':0,
 'pond_rainfall':'All rain on the entire 5000 m2 pond footprint delivered directly without losses: conservative simplification for access strip and slopes.',
 'pond_loss_credit':'No pond infiltration or evaporation credited; modeled as zero, not a measurement.',
 'tailwater':'Free discharge assumed; downstream backwater and pipe entrance/exit losses unmodeled.',
 'inlet':'All generated runoff assumed captured and conveyed; network surcharge and surface bypass unmodeled.'},
 design={**DESIGN,'outer_footprint_m':[100,50],'rim_dimensions_m':[94,44],'perimeter_access_m':3,
 'geometry_storage_m3_at_2p5m':float(storage(2.5)/.9),'net_storage_m3_at_2p5m':float(storage(2.5)),
 'capacity_derating_fraction':.1,'capacity_derating_reason':'Concept allowance for sediment, grading, structure displacement; not a measured stock.',
 'sediment_bay_plan_m':[8,8],'sediment_bay_storage_credit_m3':0,
 'outlet_pipe_concept_diameter_m':.9,'outlet_pipe_assumed_slope':.01,'outlet_pipe_Manning_n':.013,
 'outlet_pipe_full_flow_Manning_m3s':float(1/.013*math.pi*.9**2/4*(.9/4)**(2/3)*.01**.5)},
 quantities=[],boundary_fluxes=[],balances=[],unresolved=[],scenarios={},sources=[{'title':t,'url':u} for t,u in SOURCES],
 schema_notes=['Unchanged bundled DTDL v2 definitions, model version ;3.',
 'Map schema stores only value and unit. Timing, scenarios, capacities and evidence reside here.',
 'Different keys are snapshots/statistics from independent scenarios; never add peak stocks or peak rates.',
 'Boundary rainfall and lumped CN abstractions are numeric linked flow records, not artificial asset twins.',
 'Conveyance storage is neglected in routing, not asserted to be physically absent.'],
 validation={'azure_import':'not performed','official_DTDL_parser':'not run','local_checks':'see validation.json'})

def quantity(target,kind,key,value,unit,scenario,time,meaning):
 q={'value':float(value),'unit':unit}
 (byid[target]['stock'] if kind=='stock' else byrel[target]['flow'])[key]=q
 ledger['quantities'].append(dict(target=target,map=kind,key=key,**q,scenario=scenario,time_basis=time,
     meaning=meaning,basis='calculated from assumptions; calculations.py'))

allresults={**R['base'],**R['sensitivity']}
allseries={**TS,**SENS}
ledger['asset_processes']={
 'dp-hard':{'receives':'Rainfall','transforms':'Partitions rainfall into runoff and CN abstractions','accumulates':'Temporary surface/conveyance water not independently resolved','releases':'Runoff to pond; lumped abstractions to unresolved pathways'},
 'dp-land':{'receives':'Rainfall','transforms':'Partitions rainfall into runoff and CN abstractions','accumulates':'Soil and surface water, biomass: unquantified physical stocks','releases':'Runoff to pond; lumped abstractions to unresolved pathways'},
 'dp-pond':{'receives':'Hardscape runoff, landscape runoff and direct precipitation','transforms':'Attenuates hydrograph through changing water stock','accumulates':'Water quantified; sediment and vegetation unquantified','releases':'Controlled outlet and emergency overflow'},
 'dp-outlet':{'receives':'Controlled pond discharge','transforms':'Restricts discharge as a function of head','accumulates':'Internal conveyance water neglected in routing; physical stock unquantified','releases':'Water to receiving swale'},
 'dp-spill':{'receives':'Pond overflow above 2.5 m','transforms':'Conveys emergency discharge','accumulates':'Internal conveyance water neglected in routing; physical stock unquantified','releases':'Water to receiving swale'},
 'dp-reach':{'receives':'Outlet and spillway discharges plus unknown external background flow','transforms':'Downstream transport not modeled','accumulates':'Water stock unresolved','releases':'Downstream discharge unresolved; model ends at its inlet'},
 'dp-pre':{'receives':'Rainfall in pre-development scenario only','transforms':'Baseline rainfall-runoff transformation','accumulates':'Soil/surface water stocks unquantified','releases':'Counterfactual runoff to receiving swale and lumped CN abstractions'}}
for label,r in allresults.items():
 s=allseries[label];end=96
 ledger['scenarios'][label]=r
 for key,val,time in [('initial',r['initial_storage_m3'],0),('peak',r['storage_peak_m3'],r['peak_time_h']),('final',r['final_storage_m3'],96)]:
  quantity('dp-pond','stock',f'water_{key}_{label}',val,'m3',label,{'at_hour':time},f'Pond water {key} snapshot')
 for rid,rate,total in [('hardIn',max(s['hard_q_m3s']),r['hard_volume_m3']),('landIn',max(s['land_q_m3s']),r['land_volume_m3']),
                       ('controlled',r['primary_peak_m3s'],r['primary_volume_m3']),('discharge',r['primary_peak_m3s'],r['primary_volume_m3']),
                       ('overflow',r['spill_peak_m3s'],r['spill_volume_m3']),('spillDischarge',r['spill_peak_m3s'],r['spill_volume_m3']),
                       ('baseline',r['pre_peak_m3s'],r['pre_volume_m3'])]:
  for k,val,unit,tb in [('peak',rate,'m3/s',{'statistic':'maximum interval-average rate','window_h':[0,96],'interval_s':60}),
                        ('volume',total,'m3',{'integrated_window_h':[0,96]})]:
   quantity('dp-'+rid,'flow',f'water_{k}_{label}',val,unit,label,tb,'Water transfer; baseline edge belongs only to pre-development scenario' if rid=='baseline' else 'Water transfer')
 for target,area,runoff in [('dp-hard',60000,r['hard_volume_m3']),('dp-land',35000,r['land_volume_m3']),('dp-pond',5000,r['direct_volume_m3']),('dp-pre',100000,r['pre_volume_m3'])]:
  rain=r['depth_mm']/1000*area
  ledger['boundary_fluxes'].append(dict(scenario=label,source='external atmosphere',destination=target,name='precipitation',value=rain,unit='m3',time_basis={'window_h':[0,24]}))
  if target!='dp-pond':
   ledger['boundary_fluxes'].append(dict(scenario=label,source=target,destination='unresolved soil/interception/evaporation pathways',
      name='CN_lumped_abstraction',value=rain-runoff,unit='m3',time_basis={'window_h':[0,96]},
      note='Model remainder. Infiltration, interception and other retained/lost water are not separately resolved; not credited as water reuse.'))
   ledger['balances'].append(dict(scenario=label,asset=target,check='Event rainfall-runoff accounting only, not resolved soil-water balance',
      rainfall_m3=rain,runoff_m3=runoff,lumped_abstraction_m3=rain-runoff,
      residual_m3=0.,window_h=[0,96],physical_stock_change='unresolved within lumped abstractions'))
 ledger['balances'].append(dict(scenario=label,asset='dp-pond',initial_m3=r['initial_storage_m3'],
    inflow_m3=r['inflow_volume_m3'],outflow_m3=r['out_volume_m3'],final_m3=r['final_storage_m3'],
    residual_m3=r['mass_residual_m3'],window_h=[0,96],pass_absolute_1em6_m3=abs(r['mass_residual_m3'])<1e-6))
 ledger['balances'].append(dict(scenario=label,asset='dp-pond',window_h=[0,r['peak_time_h']],initial_m3=r['initial_storage_m3'],
    inflow_m3=r['peak_cumulative_in_m3'],outflow_m3=r['peak_cumulative_out_m3'],final_m3=r['storage_peak_m3'],
    residual_m3=r['initial_storage_m3']+r['peak_cumulative_in_m3']-r['peak_cumulative_out_m3']-r['storage_peak_m3']))

for target,what,impact in [('site','Local storm depths, required durations, and temporal distributions','Recurrence labels and compliance unresolved'),
 ('dp-pre','Existing ground cover, soils and flow paths','Allowable pre-development peak uncertain'),
 ('dp-pond','Survey, groundwater, bedrock and geotechnical stability','3 m excavated basin and gravity drainage unverified'),
 ('dp-pond','Sediment, biomass and construction material stocks','Unquantified; no pollutant-removal or embodied-carbon claim'),
 ('dp-hard','Inlet and pipe network capacities, bypass paths','100% capture assumption unverified'),
 ('dp-outlet','Detailed chamber geometry, tailwater and pipe HGL','Ideal outlet rating unverified in field'),
 ('dp-spill','Emergency design event, erosion resistance, overflow route','3 m crest is conceptual; blocked-outlet safety incomplete'),
 ('dp-reach','Receiving capacity, erosion limits and background flow','Downstream flood/erosion effects unverified'),
 ('site','Local setbacks, access widths, safety benches, fencing and permits','Nominal area fit is not regulatory approval'),
 ('site','Construction rates and maintenance budget','Economic comparison qualitative only')]:
 ledger['unresolved'].append(dict(target=target,quantity_or_requirement=what,value=None,status='unresolved',affected_check=impact))
dump('twins.json',twins);dump('relationships.json',rels)
graph=dict(digitalTwinsFileInfo={'fileVersion':'1.0.0'},digitalTwinsModels=MODELS,digitalTwinsGraph={'digitalTwins':twins,'relationships':rels})
dump('graph.json',graph);dump('ledger.json',ledger)

# Local export and balance verification; explicitly not official DTDL parsing.
ids={t['$dtId'] for t in twins};modelids={m['@id'] for m in MODELS}
assert len(ids)==len(twins)
assert all(t['$metadata']['$model'] in modelids for t in twins)
assert len({r['$relationshipId'] for r in rels})==len(rels)
assert all(r['$sourceId'] in ids and r['$targetId'] in ids for r in rels)
assert all(r['$relationshipName']=='flowsTo' for r in rels)
for t in twins: assert set(t)=={'$dtId','$metadata','name','system','stock'}
for q in ledger['quantities']:
 assert math.isfinite(q['value']) and isinstance(q['unit'],str)
 got=(byid[q['target']]['stock'] if q['map']=='stock' else byrel[q['target']]['flow'])[q['key']]
 assert got=={'value':q['value'],'unit':q['unit']}
for r in allresults.values():
 assert abs(r['mass_residual_m3'])<1e-6
 assert abs(r['hard_volume_m3']+r['land_volume_m3']+r['direct_volume_m3']-r['inflow_volume_m3'])<1e-6
for k,r in R['base'].items():
 assert r['peak_limit_pass'] and r['operational_storage_pass'] and r['spill_volume_m3']==0
assert (70+8*3+6)*(20+8*3+6)==5000
validation=dict(json_syntax='pass',finite_values='pass',schema_property_shapes='pass',unique_ids='pass',
 relationship_endpoints='pass',containment_cycles='not applicable: no contains edges',ledger_agreement='pass',
 rainfall_area_accounting='pass: 6+3.5+0.5=10 ha',pond_mass_balance='pass; absolute residual below 1e-6 m3',
 footprint='pass under excavated-basin assumptions',base_event_constraints='pass under illustrative assumptions',
 routing_timestep_refinement={k:{'outlet_peak_relative_change':R['refinement'][k]['out_peak_m3s']/r['out_peak_m3s']-1,
   'stage_change_m':R['refinement'][k]['depth_peak_m']-r['depth_peak_m']} for k,r in R['base'].items()},
 official_DTDL_parser='not run',azure_import='not performed',site_specific_compliance='not established',
 detailed_spillway_safety='incomplete')
dump('validation.json',validation)

# Figures, with exact geometry and calculated hydrographs.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False})
navy='#173746';teal='#147d87';blue='#4d9ec0';gray='#64747c';orange='#be6c36'
fig,(ax,sec)=plt.subplots(2,1,figsize=(9,5.2),gridspec_kw={'height_ratios':[3,1.15]})
ax.add_patch(Rectangle((0,0),100,50,fc='#f3f0e6',ec=navy,lw=1.4))
ax.add_patch(Rectangle((3,3),94,44,fc='#dce9ce',ec='#78926c',lw=1.2))
ax.add_patch(Rectangle((15,15),70,20,fc='#f9fcf2',ec='#78926c'))
h=R['base']['100y']['depth_peak_m'];margin=15-4*h
ax.add_patch(Rectangle((margin,margin),70+8*h,20+8*h,fc='none',ec=blue,lw=1.6,ls='--'))
ax.add_patch(Rectangle((17,21),8,8,fc='#ded7c6',ec=gray))
ax.text(21,25,'Sediment\nbay',ha='center',va='center',fontsize=7)
ax.text(52,25,'Vegetated dry basin\n70 x 20 m bottom',ha='center',va='center',color=navy)
ax.annotate('Inlet',xy=(17,25),xytext=(4,25),arrowprops={'arrowstyle':'->','color':navy},ha='center')
ax.plot([85,98],[25,25],color=navy,lw=2)
ax.text(95,28,'Outlet',ha='center',fontsize=8)
ax.plot([97,100],[12,12],color=orange,lw=4)
ax.text(96,8,'Overflow',ha='center',fontsize=7)
ax.text(50,47.2,'3 m perimeter access allowance',ha='center',fontsize=7)
ax.text(50,-4,'100 m overall; 94 m basin at rim',ha='center')
ax.text(-5,25,'50 m',ha='center',rotation=90)
ax.set(xlim=(-9,106),ylim=(-7,54),aspect='equal');ax.axis('off')
sec.plot([0,3,15,35,47,50],[3,3,0,0,3,3],color='#6b8a5b',lw=2)
sec.fill_between([15-4*h,15,35,35+4*h],[h,0,0,h],h,color='#c5e6ef',alpha=.8)
sec.hlines([h,2.5],[-1,-1],[51,51],color=[teal,orange],ls=['--',':'])
sec.text(51.5,h,f'100-year example: {h:.2f} m',va='center',fontsize=8)
sec.text(51.5,2.65,'Emergency crest: 2.50 m',fontsize=8)
sec.text(51.5,.3,'Rim: 3.00 m\n4H:1V side slopes',fontsize=8)
sec.set(xlim=(-1,79),ylim=(-.3,3.8));sec.axis('off')
sec.set_title('Cross-section across the 50 m footprint; vertical scale exaggerated',fontsize=8,loc='left')
fig.tight_layout();fig.savefig(P/'pond_layout.png',dpi=180,bbox_inches='tight');plt.close(fig)
fig,axs=plt.subplots(3,1,figsize=(9,6.1),sharex=True)
for ax,(label,s) in zip(axs,TS.items()):
 t=np.array(s['time_end_h'])
 ax.plot(t,s['in_q_m3s'],color=gray,label='Post-development inflow',lw=1.4)
 ax.plot(t,s['pre_q_m3s'],color=orange,label='Pre-development runoff',lw=1.4)
 ax.plot(t,s['out_q_m3s'],color=teal,label='Pond outflow',lw=1.7)
 ax.set_ylabel('Flow (m3/s)');ax.set_title(f'{label.replace("y","-year")} illustrative storm',loc='left',fontsize=10)
 ax.grid(alpha=.15);ax.set_xlim(0,48)
axs[0].legend(ncol=3,fontsize=8,loc='upper right')
axs[-1].set_xlabel('Hours since storm start (rain ends at hour 24)')
fig.tight_layout();fig.savefig(P/'hydrographs.png',dpi=180,bbox_inches='tight');plt.close(fig)

# Five-page report with controlled page breaks.
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleX',fontName='Helvetica-Bold',fontSize=26,leading=29,textColor=colors.HexColor(navy),spaceAfter=12))
styles.add(ParagraphStyle(name='SubX',fontName='Helvetica-Bold',fontSize=13,leading=17,textColor=colors.HexColor(teal),spaceBefore=12,spaceAfter=7))
styles.add(ParagraphStyle(name='BodyX',fontSize=9.3,leading=13.3,textColor=colors.HexColor(navy),spaceAfter=7))
styles.add(ParagraphStyle(name='SmallX',fontSize=7.8,leading=10.4,textColor=colors.HexColor(gray),spaceAfter=5))
styles.add(ParagraphStyle(name='CellX',fontSize=8,leading=10.5,textColor=colors.HexColor(navy)))
story=[]
def para(t,style='BodyX'):story.append(Paragraph(t,styles[style]))
def head(t):para(t,'SubX')
def table(rows,widths=None):
 data=[[Paragraph(str(c),styles['CellX']) for c in row] for row in rows]
 t=Table(data,colWidths=widths,hAlign='LEFT',repeatRows=1)
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e1edf0')),('VALIGN',(0,0),(-1,-1),'TOP'),
 ('BOTTOMPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.7,colors.HexColor(teal)),
 ('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#d5dfe1'))]))
 story.append(t);story.append(Spacer(1,7))
def page(title,kicker):
 if story:story.append(PageBreak())
 para(kicker.upper(),'SmallX');para(title,'TitleX')

page('Detention within 0.5 hectares','Concept design | 1 November 2026')
para('<b>Proposed solution:</b> an excavated dry detention basin with a screened low-level opening, a raised overflow window, a sediment bay and a separate emergency spillway. The 100 x 50 m allocation includes a 3 m perimeter access allowance.')
para('<b>Conditional finding:</b> the concept meets the three peak limits under the stated hypothetical rainfall and catchment assumptions. Local rainfall, survey, soils and downstream conditions are still required to establish site-specific performance.')
table([['Design element','Concept dimension / capacity'],['Usable detention storage','5,475 m3 below emergency crest; 10% geometry allowance deducted'],
 ['Basin geometry','70 x 20 m bottom; 4H:1V slopes; 94 x 44 m at rim'],['Levels above bottom','Emergency crest 2.50 m; rim 3.00 m'],
 ['Primary controls','200 x 200 mm bottom opening; 430 mm wide window with sill at +1.10 m'],
 ['Emergency / discharge','3 m broad-crested overflow; nominal 900 mm discharge pipe, pending hydraulic design']], [150,366])
story.append(Image(str(P/'pond_layout.png'),width=516,height=298))
para('Concept geometry only. The sediment bay occupies the basin floor; it adds no separate credited storage. All dimensions assume an excavated basin with suitable surrounding grades; an elevated embankment, safety benches or wider access could change the footprint.','SmallX')

page('An explicit design basis','Inputs, runoff and reservoir routing')
table([['Item','Supplied requirement / working assumption'],['Site and imperviousness','Supplied: 10 ha total, 60% impervious. Pond footprint is included within the site.'],
 ['Area partition','6.0 ha roofs/paving + 3.5 ha landscape + 0.5 ha pond/access = 10.0 ha.'],
 ['Pre-development','Assumed meadow on hydrologic soil group C, CN 71; concentration time 30 min.'],
 ['Post-development','Hardscape CN 98; good lawn CN 74; concentration time 15 min. All runoff captured.'],
 ['Storms','Assumed 24-hour totals: 75 / 110 / 160 mm, labeled 2 / 10 / 100 year for illustration only.'],
 ['Temporal pattern','40% in central hour, 30% in adjacent five hours, 30% in remaining eighteen hours. This is a custom synthetic pattern, not an official design distribution.'],
 ['Pond behavior','Initially dry; no infiltration or evaporation credit. All rainfall over the full 0.5 ha footprint enters the pond directly. Free outlet discharge.']], [120,396])
head('Method and physical balance')
para('CN event runoff is computed independently for each land-cover area: S = 25,400/CN - 254 mm; runoff = (P - 0.2S)^2 / (P + 0.8S) for P &gt; 0.2S, otherwise zero [1,2]. Increments are convolved with a normalized triangular response: peak time = 0.6Tc + half the time step, and base time = 2.67 times peak time. This is an explicit approximation to the SCS response, not a full HEC-HMS simulation [3].')
para('The pond uses finite-volume level-pool routing at 60 seconds: S(next) + Q(next) x dt = S(previous) + interval inflow. A 30-second rerun changes the base-event outlet peaks by less than 1%. The calculation uses both outlet levels simultaneously and includes the emergency spillway when active [4].')
para('For water depth h in metres: <b>S(h) = 0.9 x [1,400h + 360h^2 + (64/3)h^3] m3.</b> The 0.9 factor conservatively reserves 10% for grading, sediment and structures; it is a capacity allowance, not an assumed sediment stock.')
para('The bottom opening uses an integrated rectangular-orifice equation, including partial submergence. The raised window uses Q = 1.7 x 0.43 x max(h - 1.10, 0)^1.5 m3/s; the emergency crest uses Q = 1.7 x 3 x max(h - 2.50, 0)^1.5 m3/s. Coefficients are preliminary. The window must remain a free weir over the modeled range.')
para('A nominal 900 mm pipe at 1% slope and Manning n = 0.013 has about '+f"{ledger['design']['outlet_pipe_full_flow_Manning_m3s']:.2f}"+' m3/s uniform full-flow capacity. This screens pipe size only; chamber losses, tailwater, slope availability and hydraulic grade line remain unresolved.','SmallX')

page('Peak attenuation and water stocks','Calculated results | illustrative storms')
rows=[['Storm / rain','Pre peak\n(m3/s)','Pond inflow\n(m3/s)','Pond outflow\n(m3/s)','Peak water\n(m3)','Depth\n(m)']]
for k,r in R['base'].items():rows.append([f"{k.replace('y',' yr')} / {r['depth_mm']} mm",f"{r['pre_peak_m3s']:.3f}",f"{r['inflow_peak_m3s']:.3f}",f"{r['out_peak_m3s']:.3f}",f"{r['storage_peak_m3']:.0f}",f"{r['depth_peak_m']:.2f}"])
table(rows,[100,80,85,85,86,80])
story.append(Image(str(P/'hydrographs.png'),width=516,height=350))
r=R['base']['100y']
head('Stock is not capacity')
para(f"The assumed 100-year storm reaches <b>{r['storage_peak_m3']:,.0f} m3 of water</b> at hour {r['peak_time_h']:.2f}, against 5,475 m3 of usable capacity. Its water surface remains {3-r['depth_peak_m']:.2f} m below the rim. No emergency discharge occurs in the three base runs.")
para(f"At the 100-year storage peak: {r['initial_storage_m3']:.0f} + {r['peak_cumulative_in_m3']:,.2f} m3 inflow - {r['peak_cumulative_out_m3']:,.2f} m3 outflow = {r['storage_peak_m3']:,.2f} m3 stored. Pond mass-balance residuals are below 0.000001 m3; this verifies numerical accounting, not input accuracy.")

page('Stress tests and practical limits','Design revision and joint performance')
para('The initial 2.5 m-deep concept with a single low-level opening relied on emergency overflow in the largest assumed storm. The final 3.0 m-deep basin and raised window trade additional excavation for more storage and controlled release while retaining the 0.5 ha allocation. Outlet alternatives are recorded in results.json. This is a small concept comparison, not a global cost optimum.')
rows=[['100-year sensitivity','Peak depth (m)','Outflow / pre peak (m3/s)','Finding']]
names={'rain_plus20':'+20% rain (192 mm)','half_blocked':'50% primary capacity blocked','initial_0p5m':'0.50 m initial water','front_loaded':'Peak rain at hour 3','back_loaded':'Peak rain at hour 21'}
for k,r in R['sensitivity'].items():
 finding='Pass assumed criteria' if r['peak_limit_pass'] and r['operational_storage_pass'] else 'Emergency overflow used'
 rows.append([names[k],f"{r['depth_peak_m']:.3f}",f"{r['out_peak_m3s']:.3f} / {r['pre_peak_m3s']:.3f}",finding])
table(rows,[165,80,135,136])
para('For +20% rainfall, the displayed pre-development comparator is recalculated under the same 192 mm storm. It is not the original 100-year release limit. That test leaves only about 1 cm below the emergency crest: it indicates sensitivity, not a dependable climate allowance. The tests vary one factor at a time; combined adverse conditions were not tested.','SmallX')
head('What the design improves')
para('<b>Physical:</b> gravity detention balances event inflow, water accumulation and release. Peak discharge falls, but runoff volume is not restored to pre-development levels. No water-reuse, infiltration or water-quality removal benefit is credited.')
para('<b>Environmental and social:</b> a vegetated basin and sediment bay provide a practical surface treatment opportunity. Verify vegetation survival, sediment loads, public access, side-slope safety, fencing and outlet protection. Water-quality treatment and habitat performance remain unquantified.')
para('<b>Operational and economic:</b> use a removable debris screen, accessible sediment bay, staff gauge and maintenance access. Inspect after major storms and clear debris when found. Pumps and active controls are unnecessary under the assumed gravity conditions. Cost, excavation disposal and maintenance labor are not priced.')
head('Checks still needed before advancing the design')
para('Obtain site coordinates and local rainfall depths/distributions; test the required storm durations; survey existing cover, flow paths and downstream elevations; verify soils, groundwater and bedrock. Then resolve inlet capture, outlet hydraulics, overflow routing and erosion, required freeboard, setbacks and local drainage criteria.')
para('The 50% blockage run uses the spillway and reduces rim clearance below the concept 0.5 m allowance. Complete a separate blocked-outlet and emergency-event safety analysis. The assumed emergency crest width alone is not a verified safe overflow route.')

page('A populated asset model','Stocks, flows and Azure Digital Twins files')
table([['Asset twin','Role and quantified metabolism'],['Roofs & paving / Landscape','Input assets. Each runoff relationship contains numeric event volumes and peak rates for the base and sensitivity scenarios.'],
 ['Pond','Process asset. Water stock maps contain initial, peak and 96-hour snapshots for each scenario; capacity is recorded separately in the ledger.'],
 ['Outlet / Spillway','Process assets. Controlled and emergency transfers are explicit. Internal conveyance storage is neglected, not measured as zero.'],
 ['Receiving swale','External output asset. Receives both release paths. Its existing flow and capacity remain unresolved.'],
 ['Existing meadow','Alternative pre-development physical land-cover asset, used only for the baseline. Do not add its runoff to the proposed development.']], [145,371])
head('Water accounting over 96 hours')
rows=[['Storm','Pond inflow (m3)','Discharge (m3)','Final water (m3)','Drain to 10 mm* (h)']]
for k,r in R['base'].items():rows.append([k.replace('y',' yr'),f"{r['inflow_volume_m3']:.2f}",f"{r['out_volume_m3']:.2f}",f"{r['final_storage_m3']:.2f}",f"{r['hours_after_rain_to_10mm']:.1f}"])
table(rows,[66,115,115,100,120])
para('*Hours after the 24-hour rainfall ends. The model approaches empty gradually; a small residual is retained in the accounting. Local drain-down criteria and actual low-flow grading still need verification.','SmallX')
para('Rainfall boundary inputs and estimated CN abstractions are numeric records in ledger.json. Their physical partitions among infiltration, interception and other storage/losses are unresolved; they are not invented soil-stock estimates. Each quantity carries a scenario and time basis. Parallel transfer links are internal passages, so they must not be added together as additional site exports.')
head('Open the export')
para('graph.json includes the unchanged bundled model definitions and the populated twins/relationships. In Azure Digital Twins Explorer, select Import Graph, open graph.json, review and Save [5]. If these exact models already exist, upload the supplied model.json only when needed and use a copy of graph.json with digitalTwinsModels set to an empty array. Query the design with:')
para("<font face='Courier' size='8'>SELECT * FROM digitaltwins T WHERE STARTSWITH(T.$dtId, 'dp-')</font>")
para('Local checks passed for JSON, identifiers, endpoints, declared property/map shapes, ledger consistency and water balances. No official DTDL parser or live Azure import was run. The export does not remove existing twins.','SmallX')
head('References')
for i,(title,url) in enumerate(SOURCES,1):para(f'[{i}] <a href="{url}" color="#147d87">{title}</a>. Accessed 1 November 2026.','SmallX')

def footer(c,doc):
 c.setStrokeColor(colors.HexColor('#d5dfe1'));c.line(40,36,556,36)
 c.setFont('Helvetica',7);c.setFillColor(colors.HexColor(gray))
 c.drawString(40,24,'DETENTION POND | Illustrative concept; site-specific design inputs unresolved')
 c.drawRightString(556,24,str(doc.page))
doc=SimpleDocTemplate(str(P/'Detention_Pond_Concept.pdf'),pagesize=(596,842),leftMargin=40,rightMargin=40,topMargin=35,bottomMargin=48,
 title='Detention Pond Concept - 10 ha Residential Site',author='Environmental Metabolism Modeling')
doc.build(story,onFirstPage=footer,onLaterPages=footer)

readme='''DETENTION POND - ILLUSTRATIVE CONCEPT

Read Detention_Pond_Concept.pdf first. The rainfall frequency labels are assumptions,
not site-specific return periods. This package does not establish local compliance.

FILES
model.json: unchanged agreed DTDL v2 definitions (model identifiers version ;3).
graph.json: Azure Explorer envelope, model definitions and populated asset data.
twins.json / relationships.json: optional separated instance arrays.
ledger.json: scenario/time references, boundary flows, assumptions, capacities,
            unquantified quantities, sources and numerical balances.
results.json: main results, outlet alternatives, stress tests and time-step check.
timeseries.json / sensitivity_timeseries.json: interval data (96 h each).
calculations.py: reproducible runoff and reservoir routing (requires numpy).
build_package.py: reproducible model export, figures and PDF (numpy, matplotlib,
                  reportlab; writes files in this folder).
validation.json: checks actually completed and limitations.

RUN
python3 calculations.py
python3 build_package.py

AZURE EXPLORER
Import Graph -> graph.json -> review -> Save.
The graph includes model definitions. If exact models already exist, use a copy
with digitalTwinsModels: [] and retain the existing models. Do not delete them.
Query: SELECT * FROM digitaltwins T WHERE STARTSWITH(T.$dtId, 'dp-')
Actual import and official DTDL-parser validation have not been performed.

INTERPRETATION
Map keys include scenario and snapshot; snapshots cannot be added. Stock means
accumulated water, not storage capacity. The dp-pre meadow is a counterfactual
baseline, not an extra catchment. Parallel outlet transfers are internal passages,
not extra resource production. Rainfall and lumped CN abstractions are linked
boundary records because the schema only permits flow relationships between twins.
No fictitious atmosphere/resource/function twins are added.
'''
(P/'README.txt').write_text(readme)
print(json.dumps({'pdf':str(P/'Detention_Pond_Concept.pdf'),'twins':len(twins),'relationships':len(rels),
 'populated_map_entries':len(ledger['quantities']),'base':R['base'],'validation':validation},indent=2))
