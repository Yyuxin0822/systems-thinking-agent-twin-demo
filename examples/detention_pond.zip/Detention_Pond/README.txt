DETENTION POND - ILLUSTRATIVE CONCEPT

Read Detention_Pond_Concept.pdf first. The rainfall frequency labels are assumptions,
not site-specific return periods. This package does not establish local compliance.

FILES
model.json: unchanged agreed DTDL v2 definitions (model identifiers version ;3).
graph.json: Azure Explorer envelope, model definitions and populated asset data.
twins.json / relationships.json: optional separated instance arrays.
ledger.json: scenario/time references, boundary flows, assumptions, capacities,
            unquantified quantities, sources and numerical balances.
results.json: main results, outlet alternatives, stress tests and time-step check.
timeseries.json / sensitivity_timeseries.json: interval data (96 h each).
calculations.py: reproducible runoff and reservoir routing (requires numpy).
build_package.py: reproducible model export, figures and PDF (numpy, matplotlib,
                  reportlab; writes files in this folder).
validation.json: checks actually completed and limitations.

RUN
python3 calculations.py
python3 build_package.py

AZURE EXPLORER
Import Graph -> graph.json -> review -> Save.
The graph includes model definitions. If exact models already exist, use a copy
with digitalTwinsModels: [] and retain the existing models. Do not delete them.
Query: SELECT * FROM digitaltwins T WHERE STARTSWITH(T.$dtId, 'dp-')
Actual import and official DTDL-parser validation have not been performed.

INTERPRETATION
Map keys include scenario and snapshot; snapshots cannot be added. Stock means
accumulated water, not storage capacity. The dp-pre meadow is a counterfactual
baseline, not an extra catchment. Parallel outlet transfers are internal passages,
not extra resource production. Rainfall and lumped CN abstractions are linked
boundary records because the schema only permits flow relationships between twins.
No fictitious atmosphere/resource/function twins are added.
